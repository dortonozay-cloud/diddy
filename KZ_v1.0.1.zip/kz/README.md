# KZ Scripts — R6 External (clean rewrite)

KZ is a from-scratch rewrite of the user-mode client found in
`dortonozay-cloud/diddy` (NWR6V2). See **SECURITY_REVIEW.md** for what was in
the original and why it was removed. KZ contains:

- **no** network code, **no** license/HWID checks, **no** watermarks,
- **no** anti-tamper / integrity gates (rebrand freely via `src/branding.h`),
- **no** kernel driver, **no** anti-cheat bypass, **no** spoofer,
- **no** code injection — the entity cache only *reads* through the driver.

## Layout

```
assets/kz_logo.png        your logo (also embedded into the exe via src/kz_logo.h)
vendor/                   Dear ImGui (as vendored in the original, 1.67) + stb_image
src/branding.h            ALL names/titles — edit here to rebrand
src/overlay.*             transparent DX9 + ImGui window
src/ui/                   KZ silver/black theme + menu (starting point, restyle freely)
src/core/driver.h         user-mode IOCTL client (WinDrvMgr-compatible protocol)
src/core/config.*         settings struct + %APPDATA%\KZ\settings.ini
src/game/offsets.h        EVERY build-dependent value lives here
src/game/entities.*       external entity/camera reader (reads only)
src/features/             esp / aimbot / visuals
```

## Try it in 10 seconds (no game, no driver)
```
kz.exe --demo
```
Synthetic targets, full menu and ESP preview, aim output disabled. See HOW_TO_USE.md.

## Build

Windows (MSVC x64): run `build.bat` in an x64 Native Tools prompt.
Linux cross-check: `./build.sh` (MinGW) — produces `kz.exe`.

## Driver

KZ ships **no driver**. `src/core/driver.h` speaks the WinDrvMgr IOCTL
contract from the original project (`KZ_IOCTL_*` codes and `Kz*Request`
structs). If you load a compatible driver yourself, KZ's memory features
activate; without one, the menu/overlay still run and features idle.
Mouse falls back to `SendInput` when the driver has no mouse IOCTL.

## Offsets

Rainbow Six Siege patches change offsets. Everything build-dependent is in
`src/game/offsets.h` (values carried over from the original's 2026-08-26
validation, several already marked stale there). When ESP stops tracking
after a game update, update that one file against your own dump. Positions
support both the plain (`actor+0x50/0x60`) and encrypted (`mba_dec` chain)
paths; the skeleton ESP is an approximation from bone heights — the original
skeletal-mesh reader was not ported.

## Keys / config

- `INSERT` toggle menu, `END` unload.
- Settings persist to `%APPDATA%\KZ\settings.ini` (also via Misc tab buttons).

## How to use / detection reality
See **HOW_TO_USE.md** for build/run steps and the honest answer to
"is it undetected?" (short version: no one can guarantee that; the driver
you load is the detection surface; I didn't add evasion features on purpose).

## Notes

- Vendored ImGui is the same 1.67-WIP copy that shipped with the original;
  upgrading to a modern ImGui is recommended when you restyle the UI
  (`GetOverlayDrawList` → `GetForegroundDrawList` etc.).
- Cheating in online games violates the game's ToS and ruins matches for
  other players; kernel-side evasion additionally risks HWID bans. This code
  is provided for learning and private experimentation — you are
  responsible for how you use it.
