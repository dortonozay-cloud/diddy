// Host-side unit tests for the shipped KZ logic (Linux, Win32 shim).
// Executes the real sources: core/driver.h, game/entities.cpp,
// features/aimbot.cpp, core/config.cpp against a synthetic game image.
#include "core/driver.h"
#include "core/config.h"
#include "game/entities.h"
#include "game/offsets.h"
#include "features/aimbot.h"
bool g_demoMode = false;
#include <cmath>
#include <cstdio>

static int g_fail = 0, g_pass = 0;
#define CHECK(cond, msg) do { \
    if (cond) { g_pass++; printf("PASS %s\n", msg); } \
    else      { g_fail++; printf("FAIL %s\n", msg); } \
} while (0)

static bool Near(float a, float b, float eps = 0.01f) { return std::fabs(a - b) < eps; }

static uint64_t MbaDec(uint64_t x) { // same one-liner the game/encoder uses (test data only)
    return (x & 0xFFFFFFFFFFFFULL) ^ (0x100010001ULL * ((x >> 48) & 0xFFFFULL));
}

int main() {
    using namespace kztest;
    const KzOffsets& o = g_offsets;

    const uint64_t base = 0x140000000ULL;
    fakeBase = base;

    // ---- GameManager (stored compressed, <<12 on read) ----
    const uint64_t gm = 0x7FF600000000ULL;
    Put<uint64_t>(base + o.gameManagerRva, gm >> o.pointerShift);

    const uint64_t actorA = 0x1000000ULL;   // plain-position actor
    const uint64_t actorB = 0x2000000ULL;   // encrypted-position actor
    const uint64_t listArr = 0x5000000ULL;  // entityList = ptr -> actor array (stride 8)
    Put<uint64_t>(gm + o.entityList, listArr);
    Put<uint64_t>(listArr, actorA);
    Put<uint64_t>(listArr + 8, actorB);
    Put<int>(gm + o.entityCount, 2);

    // ---- actor A: plain pos, team 5, health 75 ----
    Put<uint16_t>(actorA + 0x5E, 1);
    Put<uint16_t>(actorA + 0x6E, 1);
    Vec3 pa{ 0.05f, 0.02f, 0.f };
    Put<Vec3>(actorA + o.plainPos[0], pa);
    Put<int>(actorA + o.teamId, 5);
    uint64_t h1 = 0x9000000, h2 = 0x9100000, h3 = 0x9200000;
    Put<uint64_t>(actorA + o.health0, h1);
    Put<uint64_t>(h1 + o.health1, h2);
    Put<uint64_t>(h2 + o.health2, h3);
    Put<int>(h3 + o.health3, 75);

    // ---- actor B: encrypted chain, team 7, pos (40,50,60) ----
    Put<uint16_t>(actorB + 0x5E, 0);
    Put<uint16_t>(actorB + 0x6E, 0);
    const uint64_t slot = 0x3000000, a0 = 0x3100000, a1 = 0x3200000,
                   a2 = 0x3300000, dN = 0x3400000;
    Put<uint64_t>(actorB + o.encRoots[0], slot);
    Put<uint64_t>(slot, MbaDec(a0));
    Put<uint64_t>(a0, MbaDec(a1));
    Put<uint64_t>(a1, MbaDec(a2));
    Put<uint64_t>(a2, MbaDec(dN));
    Vec3 pb{ 40.f, 50.f, 60.f };
    Put<Vec3>(dN + o.encNodeOff[0], pb);
    Put<int>(actorB + o.teamId, 7);

    // ---- camera block: origin (0,0,0), identity-ish view-proj ----
    const uint64_t cam = base + o.viewTransformRva;
    Put<Vec3>(cam + o.cameraOrigin, Vec3{ 0, 0, 0 });
    Matrix4x4 m; m.m[0] = m.m[5] = m.m[10] = m.m[15] = 1.f;
    Put<Matrix4x4>(cam + o.projectionMatrix, m);

    // ---- uworld = 0 => no local player / team ----
    Put<uint64_t>(base + o.uworldRva, 0);

    // ================= driver client =================
    static KzDriver drv;
    g_driver = &drv;
    CHECK(drv.Init(1234), "driver Init connects to device");
    CHECK(drv.GetModuleBase() == base, "GetModuleBase returns section base");
    CHECK(drv.Read<uint64_t>(base + o.gameManagerRva) == (gm >> o.pointerShift), "Read IOCTL round-trip");

    // ================= entity cache =================
    bool ok = kz::UpdateEntities(base, 1920, 1080);
    CHECK(ok, "UpdateEntities succeeds");
    const auto& pl = kz::Players();
    CHECK(pl.size() == 2, "two actors enumerated");
    const KzPlayer* A = nullptr; const KzPlayer* B = nullptr;
    for (auto& p : pl) { if (p.team == 5) A = &p; if (p.team == 7) B = &p; }
    CHECK(A && B, "teams resolved");
    if (A && B) {
        CHECK(Near(A->feet.x, 0.05f) && Near(A->feet.y, 0.02f), "plain position path");
        CHECK(A->health == 75 && A->alive, "health chain read");
        CHECK(Near(A->distance, 0.0539f, 0.001f), "distance vs camera origin");
        CHECK(Near(A->head.z, o.headHeight, 0.001f), "head height approximation");
        CHECK(Near(B->feet.x, 40.f) && Near(B->feet.z, 60.f), "encrypted position path (mba_dec)");
        float sx, sy;
        CHECK(kz::WorldToScreen(kz::Camera(), A->feet, sx, sy, 1920, 1080)
              && Near(sx, 1008.f, 0.5f) && Near(sy, 529.2f, 0.5f), "WorldToScreen math");
    }

    // ================= aimbot =================
    g_settings.aimEnabled = true;
    g_settings.aimKey = 0;
    g_settings.aimBone = 0;
    g_settings.aimSmooth = 1.f;
    g_settings.aimFov = 150.f;
    g_settings.aimTeamCheck = true;
    mouseMoves.clear();
    RunAimbot(1920, 1080);
    CHECK(mouseMoves.size() == 1 && mouseMoves[0].first == 48 && mouseMoves[0].second == -10,
          "aimbot sends smoothed move toward target (48,-10)");

    // ================= config round-trip =================
    g_settings.aimFov = 321.f;
    g_settings.espBoxCorner = false;
    g_settings.boxColor = KzColor{ 0.25f, 0.5f, 0.75f, 0.9f };
    g_settings.renderDist = 333;
    g_settings.Save();
    g_settings.aimFov = 1.f; g_settings.espBoxCorner = true; g_settings.renderDist = 1;
    g_settings.Load();
    CHECK(Near(g_settings.aimFov, 321.f) && !g_settings.espBoxCorner &&
          g_settings.renderDist == 333 && Near(g_settings.boxColor.b, 0.75f),
          "settings.ini save/load round-trip");
    remove("kztest_appdata\\KZ\\settings.ini");

    // ================= demo mode =================
    // No driver, no game: must still yield targets that project on-screen
    // with plausible, near-larger-than-far sizes.
    g_demoMode = true;
    g_driver = nullptr;
    CHECK(kz::UpdateEntities(0, 1920, 1080), "demo: UpdateEntities works with no game/driver");
    const auto& dp = kz::Players();
    CHECK(dp.size() == 3, "demo: three synthetic targets");
    float heights[3]; int onScreen = 0;
    for (size_t i = 0; i < dp.size(); i++) {
        float fx, fy, hx, hy;
        bool okf = kz::WorldToScreen(kz::Camera(), dp[i].feet, fx, fy, 1920, 1080);
        bool okh = kz::WorldToScreen(kz::Camera(), dp[i].head, hx, hy, 1920, 1080);
        if (okf && okh) { onScreen++; heights[i] = fy - hy; }
        else heights[i] = 0.f;
    }
    CHECK(onScreen == 3, "demo: all targets project on screen");
    CHECK(heights[0] > heights[1] && heights[1] > heights[2],
          "demo: nearer target renders taller than farther");
    CHECK(heights[0] > 100.f && heights[2] > 40.f,
          "demo: target boxes are visible sizes (near >100px, far >40px)");
    CHECK(kz::LocalTeam() == 5 && dp[2].team == 5,
          "demo: teammate present for team-colour preview");
    g_demoMode = false;

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
