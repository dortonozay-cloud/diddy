#pragma once
// Minimal Win32 shim so the shipped KZ logic (driver.h / entities.cpp /
// aimbot.cpp / config.cpp) can be unit-tested on Linux. Only the surface
// those files use is provided. The real Windows build never sees this header.
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cwchar>
#include <string>
#include <map>
#include <vector>
#include <functional>
#include <chrono>
#include <thread>
#include <sys/stat.h>

// ---- basic types ----
typedef int BOOL;
typedef unsigned long DWORD;
typedef unsigned int UINT;
typedef long LONG;
typedef void* HANDLE;
typedef void* HWND;
typedef wchar_t WCHAR;
typedef unsigned char BYTE;
#define TRUE 1
#define FALSE 0
#ifndef MAX_PATH
#define MAX_PATH 260
#endif
#define INVALID_HANDLE_VALUE ((HANDLE)(long long)-1)
#define GENERIC_READ 0x80000000u
#define GENERIC_WRITE 0x40000000u
#define FILE_SHARE_READ 1
#define FILE_SHARE_WRITE 2
#define OPEN_EXISTING 3
#define WINAPI
#define SUCCEEDED(x) ((long)(x) >= 0)

// ---- IOCTL encoding (same formula as Windows) ----
#define FILE_DEVICE_UNKNOWN 0x22
#define METHOD_BUFFERED 0
#define FILE_SPECIAL_ACCESS 0
#define CTL_CODE(dev, func, method, acc) \
    (((dev) << 16) | ((acc) << 14) | ((func) << 2) | (method))

// ---- input ----
#define INPUT_MOUSE 0
#define MOUSEEVENTF_MOVE 0x0001
struct MOUSEINPUT { LONG dx, dy; DWORD mouseData, dwFlags, time; uintptr_t dwExtraInfo; };
struct INPUT { DWORD type; MOUSEINPUT mi; };
typedef unsigned short WORD;

// ---- test-controlled state ----
namespace kztest {
inline std::map<uint64_t, uint8_t> mem;                      // fake process memory
inline uint64_t fakeBase = 0;                                // returned by GET_BASE
inline std::vector<std::pair<int, int>> mouseMoves;          // recorded driver mouse
inline bool driverPresent = true;

template <typename T> void Put(uint64_t addr, const T& v) {
    const uint8_t* p = (const uint8_t*)&v;
    for (size_t i = 0; i < sizeof(T); i++) mem[addr + i] = p[i];
}
template <typename T> T Get(uint64_t addr) {
    T v{};
    uint8_t* p = (uint8_t*)&v;
    for (size_t i = 0; i < sizeof(T); i++) p[i] = mem[addr + i];
    return v;
}
} // namespace kztest

// ---- kernel32-ish ----
inline DWORD GetLastError() { return 0; }
inline BOOL CloseHandle(HANDLE) { return TRUE; }
inline void Sleep(DWORD ms) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }
inline short GetAsyncKeyState(int) { return 0; }

inline HANDLE CreateFileW(const wchar_t* name, DWORD, DWORD, void*, DWORD, DWORD, void*) {
    if (!kztest::driverPresent) return INVALID_HANDLE_VALUE;
    if (name && wcsstr(name, L"WinDrvMgr")) return (HANDLE)0x1234;
    return INVALID_HANDLE_VALUE;
}

struct KzShimReadReq  { uint64_t Address, Buffer, Size; };
struct KzShimWriteReq { uint64_t Address, Buffer, Size; };
struct KzShimBaseReq  { int32_t ProcessId; uint64_t BaseAddress; };
struct KzShimMouseReq { int32_t X, Y; uint16_t Flags; };

inline BOOL DeviceIoControl(HANDLE h, DWORD code, void* in, DWORD inSz,
                            void* out, DWORD outSz, DWORD* ret, void*) {
    if (ret) *ret = 0;
    if (h != (HANDLE)0x1234) return FALSE;
    if (code == CTL_CODE(FILE_DEVICE_UNKNOWN, 0x2A4, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)) {
        auto* r = (KzShimReadReq*)in;
        uint8_t* dst = (uint8_t*)r->Buffer;
        for (uint64_t i = 0; i < r->Size; i++) dst[i] = kztest::mem[r->Address + i];
        return TRUE;
    }
    if (code == CTL_CODE(FILE_DEVICE_UNKNOWN, 0x2A5, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)) {
        auto* r = (KzShimWriteReq*)in;
        const uint8_t* src = (const uint8_t*)r->Buffer;
        for (uint64_t i = 0; i < r->Size; i++) kztest::mem[r->Address + i] = src[i];
        return TRUE;
    }
    if (code == CTL_CODE(FILE_DEVICE_UNKNOWN, 0x2A2, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)) {
        auto* r = (KzShimBaseReq*)in;
        r->BaseAddress = kztest::fakeBase;
        if (out && outSz >= sizeof(*r)) memcpy(out, r, sizeof(*r));
        return TRUE;
    }
    if (code == CTL_CODE(FILE_DEVICE_UNKNOWN, 0x3A1, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)) {
        auto* r = (KzShimMouseReq*)in;
        kztest::mouseMoves.push_back({ r->X, r->Y });
        return TRUE;
    }
    return FALSE;
}

inline UINT SendInput(UINT n, const INPUT* in, int) {
    if (n && in->type == INPUT_MOUSE)
        kztest::mouseMoves.push_back({ (int)in->mi.dx, (int)in->mi.dy });
    return n;
}

// ---- filesystem ----
inline BOOL CreateDirectoryA(const char* p, void*) { return mkdir(p, 0755) == 0 ? TRUE : FALSE; }

// ---- windowing stubs ----
inline HWND FindWindowA(const char*, const char*) { return nullptr; }

inline int _stricmp(const char* a, const char* b) { return strcasecmp(a, b); }
