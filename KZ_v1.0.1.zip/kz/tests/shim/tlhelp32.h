#pragma once
#include "windows.h"
#define TH32CS_SNAPPROCESS 2
struct PROCESSENTRY32 {
    DWORD dwSize;
    DWORD th32ProcessID;
    char szExeFile[MAX_PATH];
};
inline HANDLE CreateToolhelp32Snapshot(DWORD, DWORD) { return (HANDLE)0x5678; }
inline BOOL Process32First(HANDLE, PROCESSENTRY32*) { return FALSE; }
inline BOOL Process32Next(HANDLE, PROCESSENTRY32*) { return FALSE; }
