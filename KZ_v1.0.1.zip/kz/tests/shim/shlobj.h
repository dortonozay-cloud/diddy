#pragma once
#include "windows.h"
#define CSIDL_APPDATA 0x1a
inline long SHGetFolderPathA(void*, int, void*, DWORD, char* out) {
    strcpy(out, "kztest_appdata");
    return 0; // S_OK
}
