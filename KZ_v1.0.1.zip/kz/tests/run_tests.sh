#!/bin/bash
# Host-side logic tests (Linux). Compiles the SHIPPED sources against a Win32
# shim and runs them against a synthetic game image. Not a substitute for
# in-game testing on Windows.
set -e
cd "$(dirname "$0")/.."
g++ -std=c++17 -g -Wall -I tests/shim -I src \
  tests/test_main.cpp src/game/entities.cpp src/features/aimbot.cpp src/core/config.cpp \
  -o /tmp/kztest
/tmp/kztest
