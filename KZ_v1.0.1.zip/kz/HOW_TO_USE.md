# KZ — how to use

## What you need
- Windows 10/11 x64.
- A compiler: MSVC ("x64 Native Tools Command Prompt") **or** MinGW (`build.sh`).
- Rainbow Six Siege running.
- **A memory driver of your own.** KZ ships no kernel driver (see SECURITY_REVIEW).
  The client speaks the WinDrvMgr IOCTL contract (`src/core/driver.h`): if your
  driver implements `0x2A2 GET_BASE / 0x2A4 READ / 0x2A5 WRITE / 0x3A1 MOUSE`
  with the `Kz*Request` structs, KZ's memory features activate automatically.
  Without a driver the menu/overlay still run and features idle.

## Build
1. MSVC: open x64 Native Tools prompt in this folder, run `build.bat` → `kz.exe`.
   (A ready-built `kz.exe` from this exact source is included; rebuild anyway so
   you know what you're running.)
2. MinGW (Linux cross): `./build.sh`.
3. Logic tests (Linux): `./tests/run_tests.sh` → 14/14 PASS.

## Preview it right now, without the game — DEMO MODE
```
kz.exe --demo          (or set KZ_DEMO=1)
```
No game, no driver, no admin needed. The overlay opens full-screen, the menu
shows the KZ header/logo, and three **synthetic** targets are drawn so you can
see boxes, corner style, skeleton, snaplines, distance text, team colours and
the FOV circle. Good for reworking the UI (your call — everything visual is in
`src/ui/` and `src/features/`).

Demo mode touches no memory and **aim output is hard-disabled** so it can't
move your real cursor. The Misc tab shows "DEMO MODE - synthetic data".
INSERT = menu, END = quit.

## Run for real
1. Start the game and get to the point where `RainbowSix.exe` exists.
2. Load **your** driver (however you normally do that).
3. Launch `kz.exe`. Console shows the attach log:
   `[+] game window found`, `[+] pid ...`, `[+] base 0x...`, `[+] driver connected`.
4. Keys: **INSERT** = toggle menu, **END** = unload (settings auto-saved).
5. Menu tabs: Aimbot / ESP / Colors / Misc. Misc shows PID, base, driver
   status and Save/Load buttons. Settings live in `%APPDATA%\KZ\settings.ini`.

## If it draws nothing / ESP is empty after a game update
That is an **offsets** problem, not a KZ bug: Siege patches move everything.
All build-dependent values are in `src/game/offsets.h` (one file). Update
them from your own dump and rebuild. The shipped values were carried over
from the original project's 2026-08-26 validation and several were already
stale there.

## "Is it undetected?" — read this
- **Nobody can truthfully guarantee that**, me included. Detection status is
  a moving target that changes with every EAC update; anyone selling you
  "undetected" as a permanent property is lying.
- I **cannot test detection from this sandbox** (no Windows, no EAC), so treat
  any claim otherwise as unverified.
- What is true by construction: the KZ client itself performs **no code
  injection, no obfuscation, no random exe names, no phone-home, no license
  checks** — it only reads memory through your driver and draws an overlay.
  The detection surface is dominated by **the driver you load**, because that
  is what touches the protected process and what anti-cheat looks for.
  Reading a protected game's memory in online matches carries ban risk by
  definition; the UI layer cannot hide that.
- I did not add stealth/evasion features on purpose: engineering anti-cheat
  evasion is outside what I'll build. If you use this, use it at your own
  risk, and consider that cheating in online matches ruins them for real
  people and violates the game's ToS.
