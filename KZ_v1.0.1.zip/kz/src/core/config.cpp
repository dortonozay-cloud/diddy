// KZ settings persistence (plain INI, no dependencies).
#include "config.h"
#include "util.h"
#include "branding.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <map>

KzSettings g_settings;

static void WriteColor(FILE* f, const char* key, const KzColor& c) {
    fprintf(f, "%s=%g,%g,%g,%g\n", key, c.r, c.g, c.b, c.a);
}
static void WriteBool(FILE* f, const char* key, bool v)  { fprintf(f, "%s=%d\n", key, v ? 1 : 0); }
static void WriteFloat(FILE* f, const char* key, float v){ fprintf(f, "%s=%g\n", key, v); }
static void WriteInt(FILE* f, const char* key, int v)    { fprintf(f, "%s=%d\n", key, v); }

void KzSettings::Save() const {
    std::string path = kz::ConfigDir() + "\\" KZ_CONFIG_FILE;
    FILE* f = fopen(path.c_str(), "w");
    if (!f) return;
    WriteBool(f, "aim_enabled", aimEnabled);
    WriteFloat(f, "aim_fov", aimFov);
    WriteFloat(f, "aim_smooth", aimSmooth);
    WriteInt(f, "aim_bone", aimBone);
    WriteBool(f, "aim_teamcheck", aimTeamCheck);
    WriteInt(f, "aim_key", aimKey);
    WriteBool(f, "fov_circle", fovCircle);
    WriteBool(f, "fov_square", fovSquare);
    WriteColor(f, "fov_color", fovColor);
    WriteFloat(f, "fov_thickness", fovThickness);
    WriteBool(f, "crosshair", crosshair);
    WriteColor(f, "crosshair_color", crosshairColor);
    WriteFloat(f, "crosshair_size", crosshairSize);
    WriteBool(f, "esp_box", espBox);
    WriteBool(f, "esp_box_corner", espBoxCorner);
    WriteBool(f, "esp_box_fill", espBoxFill);
    WriteColor(f, "box_color", boxColor);
    WriteColor(f, "box_fill_color", boxFillColor);
    WriteFloat(f, "box_thickness", boxThickness);
    WriteBool(f, "esp_snapline", espSnapline);
    WriteInt(f, "snap_origin", snapOrigin);
    WriteColor(f, "snap_color", snapColor);
    WriteFloat(f, "snap_thickness", snapThickness);
    WriteBool(f, "esp_distance", espDistance);
    WriteColor(f, "dist_color", distColor);
    WriteBool(f, "esp_skeleton", espSkeleton);
    WriteColor(f, "skel_color", skelColor);
    WriteBool(f, "esp_teamcheck", espTeamCheck);
    WriteBool(f, "esp_deathcheck", espDeathCheck);
    WriteInt(f, "render_dist", renderDist);
    WriteBool(f, "rainbow", rainbowMode);
    fclose(f);
}

static std::map<std::string, std::string> ParseIni(const std::string& path) {
    std::map<std::string, std::string> kv;
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return kv;
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        char* eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        char* nl = strpbrk(eq + 1, "\r\n");
        if (nl) *nl = 0;
        kv[line] = eq + 1;
    }
    fclose(f);
    return kv;
}

static bool  GetB(const std::map<std::string,std::string>& m, const char* k, bool d)  { auto it=m.find(k); return it==m.end()?d:atoi(it->second.c_str())!=0; }
static int   GetI(const std::map<std::string,std::string>& m, const char* k, int d)   { auto it=m.find(k); return it==m.end()?d:atoi(it->second.c_str()); }
static float GetF(const std::map<std::string,std::string>& m, const char* k, float d) { auto it=m.find(k); return it==m.end()?d:(float)atof(it->second.c_str()); }
static KzColor GetC(const std::map<std::string,std::string>& m, const char* k, KzColor d) {
    auto it = m.find(k);
    if (it == m.end()) return d;
    KzColor c;
    if (sscanf(it->second.c_str(), "%f,%f,%f,%f", &c.r, &c.g, &c.b, &c.a) == 4) return c;
    return d;
}

void KzSettings::Load() {
    auto m = ParseIni(kz::ConfigDir() + "\\" KZ_CONFIG_FILE);
    if (m.empty()) return;
    aimEnabled    = GetB(m, "aim_enabled", aimEnabled);
    aimFov        = GetF(m, "aim_fov", aimFov);
    aimSmooth     = GetF(m, "aim_smooth", aimSmooth);
    aimBone       = GetI(m, "aim_bone", aimBone);
    aimTeamCheck  = GetB(m, "aim_teamcheck", aimTeamCheck);
    aimKey        = GetI(m, "aim_key", aimKey);
    fovCircle     = GetB(m, "fov_circle", fovCircle);
    fovSquare     = GetB(m, "fov_square", fovSquare);
    fovColor      = GetC(m, "fov_color", fovColor);
    fovThickness  = GetF(m, "fov_thickness", fovThickness);
    crosshair     = GetB(m, "crosshair", crosshair);
    crosshairColor= GetC(m, "crosshair_color", crosshairColor);
    crosshairSize = GetF(m, "crosshair_size", crosshairSize);
    espBox        = GetB(m, "esp_box", espBox);
    espBoxCorner  = GetB(m, "esp_box_corner", espBoxCorner);
    espBoxFill    = GetB(m, "esp_box_fill", espBoxFill);
    boxColor      = GetC(m, "box_color", boxColor);
    boxFillColor  = GetC(m, "box_fill_color", boxFillColor);
    boxThickness  = GetF(m, "box_thickness", boxThickness);
    espSnapline   = GetB(m, "esp_snapline", espSnapline);
    snapOrigin    = GetI(m, "snap_origin", snapOrigin);
    snapColor     = GetC(m, "snap_color", snapColor);
    snapThickness = GetF(m, "snap_thickness", snapThickness);
    espDistance   = GetB(m, "esp_distance", espDistance);
    distColor     = GetC(m, "dist_color", distColor);
    espSkeleton   = GetB(m, "esp_skeleton", espSkeleton);
    skelColor     = GetC(m, "skel_color", skelColor);
    espTeamCheck  = GetB(m, "esp_teamcheck", espTeamCheck);
    espDeathCheck = GetB(m, "esp_deathcheck", espDeathCheck);
    renderDist    = GetI(m, "render_dist", renderDist);
    rainbowMode   = GetB(m, "rainbow", rainbowMode);
}
