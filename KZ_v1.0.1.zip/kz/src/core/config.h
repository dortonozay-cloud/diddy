#pragma once
// ============================================================================
// KZ settings: one plain struct, saved/loaded as %APPDATA%\KZ\settings.ini.
// The menu edits these fields directly; features read them directly.
// ============================================================================
#include <cstdint>
#include <string>

struct KzColor { float r = 1.f, g = 1.f, b = 1.f, a = 1.f; };

struct KzSettings {
    // ---- aimbot ----
    bool  aimEnabled   = false;
    float aimFov       = 150.f;
    float aimSmooth    = 5.f;
    int   aimBone      = 0;        // 0 head, 1 neck, 2 chest, 3 pelvis
    bool  aimTeamCheck = true;
    int   aimKey       = 0;        // virtual key code, 0 = always
    bool  fovCircle    = false;
    bool  fovSquare    = false;
    KzColor fovColor{ 1.f, 1.f, 1.f, .7f };
    float fovThickness = 1.f;
    bool  crosshair    = false;
    KzColor crosshairColor{ 0.f, 1.f, 0.f, 1.f };
    float crosshairSize = 8.f;

    // ---- esp ----
    bool  espBox       = true;
    bool  espBoxCorner = true;
    bool  espBoxFill   = false;
    KzColor boxColor{ 1.f, 0.f, 0.f, 1.f };
    KzColor boxFillColor{ 1.f, 0.f, 0.f, .15f };
    float boxThickness = 1.5f;
    bool  espSnapline  = false;
    int   snapOrigin   = 1;        // 0 bottom, 1 center, 2 top
    KzColor snapColor{ 1.f, 1.f, 0.f, 1.f };
    float snapThickness = 1.f;
    bool  espDistance  = true;
    KzColor distColor{ 1.f, 1.f, 1.f, 1.f };
    bool  espSkeleton  = false;
    KzColor skelColor{ .8f, .8f, .8f, 1.f };
    bool  espTeamCheck = true;
    bool  espDeathCheck = true;
    int   renderDist   = 250;

    // ---- misc ----
    bool  rainbowMode  = false;

    void Save() const;
    void Load();
};

extern KzSettings g_settings;
