#pragma once
// ============================================================================
// KZ Scripts branding — single source of truth for all names/titles.
// Edit here to rebrand; nothing else in the codebase hardcodes names.
// ============================================================================

#define KZ_NAME            "KZ"
#define KZ_FULL_NAME       "KZ Scripts"
#define KZ_VERSION         "1.0.1"
#define KZ_WINDOW_TITLE    "KZ Overlay"
#define KZ_CONSOLE_BANNER  "[*] KZ Scripts - R6 External"
#define KZ_CONFIG_DIR      "KZ"          // %APPDATA%\KZ
#define KZ_CONFIG_FILE     "settings.ini"
