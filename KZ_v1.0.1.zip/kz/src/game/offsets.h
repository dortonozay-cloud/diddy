#pragma once
// ============================================================================
// KZ offsets table — ALL game-build-dependent values live here.
//
// These values were carried over from the project KZ was rewritten from
// (validated against its 2026-08-26 dump). Rainbow Six Siege updates change
// them; when ESP/aimbot stop working after a game patch, update THIS file.
// Verify against your own game dump before playing.
// ============================================================================
#include <cstdint>

struct KzOffsets {
    // GameManager pointer, stored compressed in the image (value >> 12).
    uint64_t gameManagerRva  = 0x11216582;
    int      pointerShift    = 12;

    // Entity list under GameManager: a POINTER to the actor array
    // (legacy backup values — verify per build).
    uint64_t entityList      = 0x98;
    uint64_t entityCount     = 0xA0;
    uint64_t entityStride    = 0x8;

    // Local player chain (UWorld style; STALE in the Aug-2026 dump, kept as
    // fallback for team resolution).
    uint64_t uworldRva       = 0x10AEC0B8;
    uint64_t gameInstance    = 0x1B8;
    uint64_t localPlayers    = 0x38;
    uint64_t playerController= 0x30;
    uint64_t localPawn       = 0x338;

    // Per-actor fields.
    uint64_t teamId          = 0x10E0;
    // Health chain: pawn+0x18 -> +0xD8 -> +0x8 -> +0x1BC
    uint64_t health0         = 0x18;
    uint64_t health1         = 0xD8;
    uint64_t health2         = 0x08;
    uint64_t health3         = 0x1BC;

    // Position read paths (plain floats on the actor, or encrypted pointer
    // chains decoded with mba_dec).
    uint64_t plainPos[2]     = { 0x50, 0x60 };
    uint64_t encRoots[2]     = { 0x20, 0x30 };
    uint64_t encNodeOff[2]   = { 0x30, 0x00 };

    // View transform: base + viewTransformRva holds the camera block.
    // (STALE in the Aug-2026 dump; if the scan-based resolver is not present,
    // update this RVA per build.)
    uint64_t viewTransformRva   = 0xE49C7E0;
    uint64_t projectionMatrix   = 0x250;   // Matrix4x4 at camBlock+0x250
    uint64_t cameraOrigin       = 0x190;   // Vec3 at camBlock+0x190

    // Approximate bone heights (meters above the actor origin at the feet).
    // The rewritten client does not read the skeletal mesh; the skeleton ESP
    // draws an approximation from these heights.
    float headHeight   = 1.62f;
    float neckHeight   = 1.45f;
    float chestHeight  = 1.25f;
    float pelvisHeight = 0.95f;
    float bodyHeight   = 1.72f;   // top of the ESP box
};

inline KzOffsets g_offsets;
