// KZ ESP rendering.
#include "esp.h"
#include "../core/config.h"
#include "../game/entities.h"
#include "../game/offsets.h"
#include <imgui.h>
#include <cmath>

static ImU32 Col(const KzColor& c) {
    return IM_COL32((int)(c.r * 255), (int)(c.g * 255), (int)(c.b * 255), (int)(c.a * 255));
}

static ImU32 Rainbow(float alpha, float offset) {
    float h = fmodf((float)ImGui::GetTime() * 0.3f + offset, 1.0f);
    float r, g, b;
    ImGui::ColorConvertHSVtoRGB(h, 1.f, 1.f, r, g, b);
    return IM_COL32((int)(r * 255), (int)(g * 255), (int)(b * 255), (int)(alpha * 255));
}

static bool Filtered(const KzPlayer& p) {
    const KzSettings& s = g_settings;
    if (p.isLocal) return true;
    if (s.espTeamCheck && kz::LocalTeam() >= 0 && p.team == kz::LocalTeam()) return true;
    if (s.espDeathCheck && !p.alive) return true;
    if (p.distance > (float)s.renderDist) return true;
    return false;
}

void RenderEsp(int W, int H) {
    const KzSettings& s = g_settings;
    const KzCamera& cam = kz::Camera();
    if (!cam.valid) return;
    ImDrawList* dl = ImGui::GetOverlayDrawList();

    int idx = 0;
    for (const KzPlayer& p : kz::Players()) {
        if (Filtered(p)) continue;
        idx++;

        float fx, fy, hx, hy;
        if (!kz::WorldToScreen(cam, p.feet, fx, fy, W, H)) continue;
        if (!kz::WorldToScreen(cam, p.head, hx, hy, W, H)) continue;

        float boxH = fy - hy;
        if (boxH < 4.f) continue;
        float boxW = boxH * 0.42f;
        float top = hy - boxH * 0.06f;
        float bottom = fy;
        float cx = (fx + hx) * 0.5f;

        ImU32 boxCol = s.rainbowMode ? Rainbow(s.boxColor.a, idx * 0.11f) : Col(s.boxColor);

        // ---- box ----
        if (s.espBox) {
            if (s.espBoxFill)
                dl->AddRectFilled(ImVec2(cx - boxW * .5f, top), ImVec2(cx + boxW * .5f, bottom),
                                  Col(s.boxFillColor));
            if (s.espBoxCorner) {
                float cl = boxH * 0.22f;
                const ImVec2 tl(cx - boxW * .5f, top), tr(cx + boxW * .5f, top);
                const ImVec2 bl(cx - boxW * .5f, bottom), br(cx + boxW * .5f, bottom);
                dl->AddLine(tl, ImVec2(tl.x + cl, tl.y), boxCol, s.boxThickness);
                dl->AddLine(tl, ImVec2(tl.x, tl.y + cl), boxCol, s.boxThickness);
                dl->AddLine(tr, ImVec2(tr.x - cl, tr.y), boxCol, s.boxThickness);
                dl->AddLine(tr, ImVec2(tr.x, tr.y + cl), boxCol, s.boxThickness);
                dl->AddLine(bl, ImVec2(bl.x + cl, bl.y), boxCol, s.boxThickness);
                dl->AddLine(bl, ImVec2(bl.x, bl.y - cl), boxCol, s.boxThickness);
                dl->AddLine(br, ImVec2(br.x - cl, br.y), boxCol, s.boxThickness);
                dl->AddLine(br, ImVec2(br.x, br.y - cl), boxCol, s.boxThickness);
            } else {
                dl->AddRect(ImVec2(cx - boxW * .5f, top), ImVec2(cx + boxW * .5f, bottom),
                            boxCol, 0.f, 0, s.boxThickness);
            }
        }

        // ---- snaplines ----
        if (s.espSnapline) {
            float oy = s.snapOrigin == 0 ? (float)H : s.snapOrigin == 1 ? H * .5f : 0.f;
            dl->AddLine(ImVec2(W * .5f, oy), ImVec2(cx, top + boxH * .5f),
                        s.rainbowMode ? Rainbow(s.snapColor.a, idx * 0.13f) : Col(s.snapColor),
                        s.snapThickness);
        }

        // ---- distance ----
        if (s.espDistance) {
            char buf[32];
            snprintf(buf, sizeof(buf), "%dm", (int)p.distance);
            ImVec2 ts = ImGui::CalcTextSize(buf);
            dl->AddText(ImVec2(cx - ts.x * .5f, bottom + 2.f), Col(s.distColor), buf);
        }

        // ---- skeleton (approximated from bone heights) ----
        if (s.espSkeleton) {
            const KzOffsets& o = g_offsets;
            float w2 = boxW * .5f;
            auto yOf = [&](float hgt) {
                // linear interp between feet(bottom) and head(top)
                float t = hgt / o.bodyHeight;
                return bottom - boxH * t;
            };
            float yHead = yOf(o.headHeight),
                  yChest = yOf(o.chestHeight), yPelv = yOf(o.pelvisHeight);
            ImU32 sk = Col(s.skelColor);
            dl->AddLine(ImVec2(cx, yHead), ImVec2(cx, yPelv), sk, 1.2f);          // spine
            dl->AddLine(ImVec2(cx - w2 * .8f, yChest), ImVec2(cx + w2 * .8f, yChest), sk, 1.2f); // arms
            dl->AddLine(ImVec2(cx, yPelv), ImVec2(cx - w2 * .6f, bottom), sk, 1.2f); // legs
            dl->AddLine(ImVec2(cx, yPelv), ImVec2(cx + w2 * .6f, bottom), sk, 1.2f);
            dl->AddCircle(ImVec2(cx, yHead - boxH * 0.05f), boxH * 0.09f, sk, 12, 1.2f); // head
        }
    }
}
