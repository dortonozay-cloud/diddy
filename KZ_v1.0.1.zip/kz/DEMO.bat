@echo off
rem KZ preview: synthetic targets, no game and no driver needed.
cd /d "%~dp0"
kz.exe --demo
