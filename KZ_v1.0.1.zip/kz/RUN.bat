@echo off
rem KZ normal run: waits for RainbowSix.exe, then attaches.
cd /d "%~dp0"
kz.exe
