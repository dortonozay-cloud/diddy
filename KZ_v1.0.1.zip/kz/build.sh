#!/bin/bash
# KZ cross-compile check (Linux + MinGW). On Windows use build.bat instead.
set -e
cd "$(dirname "$0")"
CXX=${CXX:-x86_64-w64-mingw32-g++}
$CXX -std=c++17 -O2 -Wall \
  -I src -I vendor -I vendor/imgui \
  src/main.cpp src/overlay.cpp \
  src/ui/menu.cpp src/ui/theme.cpp \
  src/core/config.cpp \
  src/game/entities.cpp \
  src/features/esp.cpp src/features/aimbot.cpp src/features/visuals.cpp \
  vendor/imgui/imgui.cpp vendor/imgui/imgui_draw.cpp vendor/imgui/imgui_widgets.cpp \
  vendor/imgui/imgui_impl_dx9.cpp vendor/imgui/imgui_impl_win32.cpp \
  -ld3d9 -limm32 -lshell32 -lgdi32 -luser32 -static \
  -o kz.exe
echo "BUILD OK: kz.exe"
