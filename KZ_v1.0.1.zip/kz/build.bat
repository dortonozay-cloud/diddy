@echo off
rem KZ build — run from an "x64 Native Tools Command Prompt".
cl /std:c++17 /O2 /W3 /EHsc /MT ^
  /I src /I vendor /I vendor\imgui ^
  src\main.cpp src\overlay.cpp ^
  src\ui\menu.cpp src\ui\theme.cpp ^
  src\core\config.cpp ^
  src\game\entities.cpp ^
  src\features\esp.cpp src\features\aimbot.cpp src\features\visuals.cpp ^
  vendor\imgui\imgui.cpp vendor\imgui\imgui_draw.cpp vendor\imgui\imgui_widgets.cpp ^
  vendor\imgui\imgui_impl_dx9.cpp vendor\imgui\imgui_impl_win32.cpp ^
  /link d3d9.lib imm32.lib shell32.lib user32.lib gdi32.lib /OUT:kz.exe
echo Done.
