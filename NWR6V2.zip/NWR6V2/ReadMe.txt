Hey, I'm Merlyn.

Discord: Merlyn.ai
Discord Server: https://discord.gg/Fs4fSDFSSc

## About This Project

This project is based on the **Paster Six** source and includes a working driver.

**Driver status: Working as of 6.26.202

The source can be pretty annoying to work with, and there is **a lot of dead code** throughout the project. Some parts may be messy, outdated, or more complicated than they really need to be.

That said, I hope you enjoy looking through it, experimenting with it, and learning from it.

Have fun, and good luck!

— Merlyn