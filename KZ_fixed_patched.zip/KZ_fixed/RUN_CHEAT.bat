@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo ========================================
echo   KZ R6 External - Loader
echo ========================================
echo.

net session >nul 2>&1
if errorlevel 1 (
    echo [!] Run as Administrator
    pause & exit /b 1
)

:: Find kdmapper exe — built to mapper\x64\Release\kdmapper_Release.exe
set "KDMAPPER=mapper\x64\Release\kdmapper_Release.exe"
if not exist "%KDMAPPER%" (
    echo [!] kdmapper not found at %KDMAPPER%
    echo [*] Run BUILD_EVERYTHING.bat first
    pause & exit /b 1
)

if not exist "driver\Build\Release\KZKM.sys" (
    echo [!] KZKM.sys not found
    echo [*] Run BUILD_EVERYTHING.bat first
    pause & exit /b 1
)

if not exist "bin\kz.exe" (
    echo [!] kz.exe not found
    echo [*] Run BUILD_EVERYTHING.bat first
    pause & exit /b 1
)

echo [*] Mapping driver into kernel...
"%KDMAPPER%" "driver\Build\Release\KZKM.sys"
if errorlevel 1 (
    echo [!] kdmapper failed - check that R6 is not running yet or try again
    pause & exit /b 1
)

echo [*] Driver mapped. Waiting for init...
timeout /t 2 /nobreak >nul

echo [*] Launching kz.exe...
start "" "bin\kz.exe"

echo.
echo [+] Running!
echo [+] INSERT = menu   END = unload kz
echo [+] Press any key here when done playing to close kz
pause

taskkill /f /im kz.exe >nul 2>&1
echo [+] Done. Reboot to fully unload driver from kernel.
pause
endlocal
