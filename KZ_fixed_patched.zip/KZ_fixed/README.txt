KZ R6 EXTERNAL - COMPLETE PACKAGE
=================================
Everything included. No downloads needed.
Only requirement: VS2022 with C++ workload + WDK (already installed).

====================================
HOW TO USE
====================================

STEP 1 - BUILD EVERYTHING (first time only):
    Run: BUILD_EVERYTHING.bat
    Builds: kdmapper.exe, KZKM.sys, kz.exe

STEP 2 - PLAY (every time):
    Run: RUN_CHEAT.bat as Administrator

    This maps the driver into kernel and starts kz.exe.
    Menu key: INSERT
    Unload key: END

STEP 3 - DONE PLAYING:
    Close kz.exe window, reboot PC to unload driver.

NOTE: After a game update, offsets may break.
      New offsets go in: src\game\offsets.h
      Then rebuild with BUILD_EVERYTHING.bat.

====================================
TROUBLESHOOTING
====================================

"MSBuild not found"
-> Install VS2022 with Desktop C++ workload

"Driver build failed" / "is WDK installed?"
-> Install WDK: https://learn.microsoft.com/windows-hardware/drivers/download-the-wdk
-> Restart PC after installing WDK

"kdmapper failed" when running
-> Run as Administrator
-> Windows may have patched the vulnerable Intel driver
-> If so, an updated kdmapper is needed (check github.com/TheCruZ/kdmapper)

"Game crashes on launch"
-> Offsets outdated (game patched) - update offsets.h and rebuild

"[!] KZKM.sys not built yet"
-> Run BUILD_EVERYTHING.bat first

====================================
WHAT'S INCLUDED
====================================

BUILD_EVERYTHING.bat - Builds kdmapper + driver + usermode
RUN_CHEAT.bat        - Maps driver + launches cheat (run as admin)
mapper\              - kdmapper full source (builds kdmapper.exe)
driver\              - KZKM kernel driver source
src\                 - kz.exe usermode source
patch_driverh.py     - Build-time device name patcher
