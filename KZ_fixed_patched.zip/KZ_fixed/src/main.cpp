// ============================================================================
// KZ Scripts — R6 external client (clean rewrite).
//
// Boot: find game -> connect driver -> create overlay -> run features.
// INSERT toggles the menu, END unloads. Settings persist to %APPDATA%\KZ.
//
//   kz.exe            normal operation (waits for RainbowSix.exe)
//   kz.exe --demo     UI/ESP preview, no game and no driver required
// ============================================================================
#include "branding.h"
#include "state.h"
#include "core/util.h"
#include "core/driver.h"
#include "core/config.h"
#include "overlay.h"
#include "ui/menu.h"
#include "game/entities.h"
#include "features/esp.h"
#include "features/aimbot.h"
#include "features/visuals.h"
#include "game/scanner.h"

#include <cstdio>
#include <cstring>
#include <cstdlib>

uint64_t g_gameBase = 0;
DWORD    g_gamePid  = 0;
int      g_screenW  = 0;
int      g_screenH  = 0;
bool     g_demoMode = false;

int main(int argc, char** argv) {
    for (int i = 1; i < argc; i++)
        if (std::strcmp(argv[i], "--demo") == 0) g_demoMode = true;
    if (std::getenv("KZ_DEMO")) g_demoMode = true;

    printf("%s\n", KZ_CONSOLE_BANNER);
    printf("[*] v" KZ_VERSION "%s\n\n", g_demoMode ? "  [DEMO MODE]" : "");

    g_settings.Load();

    static KzDriver drv;
    HWND game = nullptr;

    if (g_demoMode) {
        printf("[demo] synthetic targets - aim output disabled\n");
        printf("[demo] INSERT = menu, END = quit\n\n");
    } else {
        printf("[*] waiting for game window...\n");
        while (!game) {
            game = kz::FindGameWindow();
            if (!game) Sleep(500);
        }
        printf("[+] game window found\n");

        for (int i = 0; i < 30 && !g_gamePid; i++) {
            g_gamePid = kz::FindProcessId("RainbowSix.exe");
            if (!g_gamePid) Sleep(1000);
        }
        if (!g_gamePid) { printf("[!] game process not found\n"); return 1; }
        printf("[+] pid %lu\n", (unsigned long)g_gamePid);

        g_driver = &drv;
        drv.Init(g_gamePid);
        if (drv.Available()) {
            g_gameBase = drv.GetModuleBase();
            printf("[+] base 0x%llX\n", (unsigned long long)g_gameBase);
        printf("[*] scanning for offsets...\n");
        kz::ScanOffsets(g_gameBase, g_gamePid);
        } else {
            printf("[!] no driver - overlay/menu will run, memory features idle\n");
        }
    }

    if (!kzoverlay::Init()) { printf("[!] overlay init failed\n"); return 1; }
    kzui::Init(kzoverlay::Device());
    kzoverlay::SetGameWindow(game);   // null in demo => full screen
    printf("[+] overlay ready (INSERT = menu, END = unload)\n");

    bool menuOpen = true;
    while (kzoverlay::BeginFrame()) {
        if (GetAsyncKeyState(VK_INSERT) & 1) menuOpen = !menuOpen;
        if (GetAsyncKeyState(VK_END) & 1) break;
        kzoverlay::SetClickThrough(!menuOpen);

        kzoverlay::GetSize(g_screenW, g_screenH);
        kz::UpdateEntities(g_gameBase, g_screenW, g_screenH);

        if (menuOpen) kzui::Render(menuOpen);
        RenderEsp(g_screenW, g_screenH);
        RenderVisuals(g_screenW, g_screenH);
        RunAimbot(g_screenW, g_screenH);

        kzoverlay::EndFrame();
        Sleep(1);
    }

    g_settings.Save();
    kzui::Shutdown();
    kzoverlay::Shutdown();
    drv.Close();
    return 0;
}
