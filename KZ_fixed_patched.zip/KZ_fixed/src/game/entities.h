#pragma once
// ============================================================================
// KZ entity cache — plain external reads via the driver client.
// No code injection, no hooks: every value arrives through read IOCTLs.
// ============================================================================
#include <cstdint>
#include <vector>
#include <deque>

struct Vec3 { float x = 0, y = 0, z = 0; };
struct Matrix4x4 { float m[16] = {}; };

// Screen-space point stored for trail history
struct TrailPoint {
    float x, y;
    float alpha;   // fades from 1.0 -> 0.0 as it ages
};

struct KzPlayer {
    uint64_t actor = 0;
    Vec3 feet;            // actor origin (ground level)
    Vec3 head;            // approximated from offsets.headHeight
    float distance = 0;
    int  team = -1;
    int  health = 100;
    bool alive = true;
    bool isLocal = false;
    // screen space (valid when onScreen)
    float sx = 0, sy = 0;
    bool onScreen = false;
    // trail: screen-space history of foot positions, newest first
    std::deque<TrailPoint> trail;
};

struct KzCamera {
    Matrix4x4 viewProj;
    Vec3 origin;
    bool valid = false;
};

namespace kz {

// World -> screen using the game's view-projection matrix.
bool WorldToScreen(const KzCamera& cam, const Vec3& world, float& outX, float& outY,
                   int screenW, int screenH);

// Refresh the cache. Returns true when at least the camera block was read.
bool UpdateEntities(uint64_t gameBase, int screenW, int screenH);

const std::vector<KzPlayer>& Players();
const KzCamera& Camera();
int LocalTeam();

} // namespace kz
