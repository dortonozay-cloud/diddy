// KZ entity cache implementation.
#include "entities.h"
#include "offsets.h"
#include "../core/driver.h"
#include "../core/config.h"
#include "../state.h"
#include <cmath>
#include <mutex>
#include <algorithm>

namespace kz {

static std::vector<KzPlayer> s_players;
static KzCamera s_camera;
static int s_localTeam = -1;
static std::mutex s_mtx;

// How many screen-space points to keep in the trail deque
static constexpr int   TRAIL_MAX_POINTS = 48;
// Alpha decay per frame (at ~60fps this fades fully in ~0.8s)
static constexpr float TRAIL_ALPHA_DECAY = 0.021f;

static bool ValidAddr(uint64_t p) { return p > 0x10000ULL && p < 0x7FFFFFFFFFFFULL; }

static bool ValidWorld(const Vec3& v) {
    if (!std::isfinite(v.x) || !std::isfinite(v.y) || !std::isfinite(v.z)) return false;
    return std::fabs(v.x) < 100000.f && std::fabs(v.y) < 100000.f && std::fabs(v.z) < 100000.f;
}

// MBA decrypt used by R6 for encrypted position pointer chains
static inline uint64_t MbaDec(uint64_t x) {
    return (x & 0xFFFFFFFFFFFFULL) ^ (0x100010001ULL * ((x >> 48) & 0xFFFFULL));
}

static bool TryPlainPos(KzDriver& d, uint64_t actor, Vec3& out) {
    for (int i = 0; i < 2; i++) {
        Vec3 v = d.Read<Vec3>(actor + g_offsets.plainPos[i]);
        if (ValidWorld(v)) { out = v; return true; }
    }
    return false;
}

static bool TryEncryptedPos(KzDriver& d, uint64_t actor, Vec3& out) {
    for (int ri = 0; ri < 2; ri++) {
        uint64_t slot = d.Read<uint64_t>(actor + g_offsets.encRoots[ri]);
        if (!ValidAddr(slot)) continue;
        uint64_t val = d.Read<uint64_t>(slot);
        if (!val) continue;
        uint64_t dec = 0;
        bool ok = true;
        for (int step = 0; step < 4; ++step) {
            dec = MbaDec(val);
            if (step == 3) break;
            if (!ValidAddr(dec)) { ok = false; break; }
            val = d.Read<uint64_t>(dec);
            if (!val) { ok = false; break; }
        }
        if (!ok || !ValidAddr(dec)) continue;
        for (int ni = 0; ni < 2; ni++) {
            Vec3 v = d.Read<Vec3>(dec + g_offsets.encNodeOff[ni]);
            if (ValidWorld(v)) { out = v; return true; }
        }
    }
    return false;
}

static bool ReadActorOrigin(KzDriver& d, uint64_t actor, Vec3& out) {
    uint16_t f5e = d.Read<uint16_t>(actor + 0x5E);
    uint16_t f6e = d.Read<uint16_t>(actor + 0x6E);
    if ((f5e == 0 || f6e == 0) && TryEncryptedPos(d, actor, out)) return true;
    if (TryPlainPos(d, actor, out)) return true;
    return TryEncryptedPos(d, actor, out);
}

static int ReadActorHealth(KzDriver& d, uint64_t pawn) {
    const KzOffsets& o = g_offsets;
    uint64_t a = d.Read<uint64_t>(pawn + o.health0);
    if (!ValidAddr(a)) return 100;
    uint64_t b = d.Read<uint64_t>(a + o.health1);
    if (!ValidAddr(b)) return 100;
    uint64_t c = d.Read<uint64_t>(b + o.health2);
    if (!ValidAddr(c)) return 100;
    int hp = d.Read<int>(c + o.health3);
    if (hp < 0 || hp > 120) return 100;
    return hp;
}

bool WorldToScreen(const KzCamera& cam, const Vec3& w, float& outX, float& outY,
                   int W, int H) {
    if (!cam.valid) return false;
    const float* m = cam.viewProj.m;
    float ww = m[3] * w.x + m[7] * w.y + m[11] * w.z + m[15];
    if (ww < 0.001f) return false;
    outX = (W * .5f) * (w.x * m[0] + w.y * m[4] + w.z * m[8]  + m[12]) / ww + W * .5f;
    outY = -(H * .5f) * (w.x * m[1] + w.y * m[5] + w.z * m[9] + m[13]) / ww + H * .5f;
    return outX >= -64 && outY >= -64 && outX <= W + 64 && outY <= H + 64;
}

// ---------------------------------------------------------------------------
// Trail helpers
// ---------------------------------------------------------------------------

// Carry trail history forward from the previous frame's player list.
// Matched by actor address. New point appended at front, oldest popped from back.
// All existing points have their alpha decayed each frame.
static void UpdateTrail(KzPlayer& p, const std::vector<KzPlayer>& prev,
                        const KzCamera& cam, int W, int H) {
    // Find matching entry from last frame
    for (const KzPlayer& old : prev) {
        if (old.actor == p.actor) {
            p.trail = old.trail;
            break;
        }
    }

    // Decay existing points
    for (TrailPoint& tp : p.trail)
        tp.alpha -= TRAIL_ALPHA_DECAY;

    // Remove fully faded points
    while (!p.trail.empty() && p.trail.back().alpha <= 0.f)
        p.trail.pop_back();

    // Cap length
    while ((int)p.trail.size() >= TRAIL_MAX_POINTS)
        p.trail.pop_back();

    // Push current foot screen position as newest point
    float sx, sy;
    if (p.onScreen && WorldToScreen(cam, p.feet, sx, sy, W, H)) {
        TrailPoint tp{ sx, sy, 1.0f };
        p.trail.push_front(tp);
    }
}

// ---------------------------------------------------------------------------
// Demo mode: synthetic targets
// ---------------------------------------------------------------------------
static void SeedDemo(int screenW, int screenH) {
    const KzOffsets& o = g_offsets;

    s_camera = KzCamera{};
    s_camera.viewProj.m[0] = 1.f;
    s_camera.viewProj.m[9] = 1.f;
    s_camera.viewProj.m[7] = 1.f;
    s_camera.origin = Vec3{ 0.f, 0.f, 0.f };
    s_camera.valid = true;
    s_localTeam = 5;

    struct DemoDef { float x, depth, health; int team; };
    const DemoDef defs[] = {
        { -1.2f,  4.0f, 100, 7 },
        {  1.0f,  7.0f,  62, 7 },
        {  2.2f, 11.0f,  88, 5 },
    };

    // Build new list, carrying trail history forward
    std::vector<KzPlayer> next;
    static uint64_t demoActors[3] = { 0x1001, 0x1002, 0x1003 };

    for (int i = 0; i < 3; i++) {
        const DemoDef& d = defs[i];
        KzPlayer p;
        p.actor    = demoActors[i];
        p.feet     = Vec3{ d.x, d.depth, -1.7f };
        p.head     = Vec3{ d.x, d.depth, -1.7f + o.headHeight };
        p.team     = d.team;
        p.health   = (int)d.health;
        p.alive    = true;
        p.distance = std::sqrt(d.x * d.x + d.depth * d.depth + 1.7f * 1.7f);
        p.onScreen = WorldToScreen(s_camera, p.feet, p.sx, p.sy, screenW, screenH);
        UpdateTrail(p, s_players, s_camera, screenW, screenH);
        next.push_back(std::move(p));
    }
    s_players.swap(next);
}

bool UpdateEntities(uint64_t gameBase, int screenW, int screenH) {
    if (g_demoMode) {
        std::lock_guard<std::mutex> lk(s_mtx);
        SeedDemo(screenW, screenH);
        return true;
    }
    if (!g_driver || !g_driver->Available() || gameBase == 0) return false;
    KzDriver& d = *g_driver;
    const KzOffsets& o = g_offsets;

    std::vector<KzPlayer> next;
    KzCamera cam;

    uint64_t camBlock = gameBase + o.viewTransformRva;
    cam.viewProj = d.Read<Matrix4x4>(camBlock + o.projectionMatrix);
    cam.origin   = d.Read<Vec3>(camBlock + o.cameraOrigin);
    cam.valid    = ValidWorld(cam.origin);

    uint64_t gm = d.Read<uint64_t>(gameBase + o.gameManagerRva);
    if (o.pointerShift > 0) gm <<= o.pointerShift;

    int localTeam = -1;
    if (ValidAddr(gm)) {
        uint64_t list  = d.Read<uint64_t>(gm + o.entityList);
        int      count = d.Read<int>(gm + o.entityCount);
        if (count < 0 || count > 64) count = 0;

        uint64_t uworld = d.Read<uint64_t>(gameBase + o.uworldRva);
        if (ValidAddr(uworld)) {
            uint64_t gi   = d.Read<uint64_t>(uworld + o.gameInstance);
            uint64_t lp   = ValidAddr(gi) ? d.Read<uint64_t>(gi + o.localPlayers) : 0;
            uint64_t pc   = ValidAddr(lp) ? d.Read<uint64_t>(lp + o.playerController) : 0;
            uint64_t pawn = ValidAddr(pc) ? d.Read<uint64_t>(pc + o.localPawn) : 0;
            if (ValidAddr(pawn)) {
                localTeam = d.Read<int>(pawn + o.teamId);
                KzPlayer local;
                local.actor   = pawn;
                local.isLocal = true;
                if (ReadActorOrigin(d, pawn, local.feet)) {
                    local.head     = { local.feet.x, local.feet.y, local.feet.z + o.headHeight };
                    local.onScreen = WorldToScreen(cam, local.feet, local.sx, local.sy, screenW, screenH);
                    UpdateTrail(local, s_players, cam, screenW, screenH);
                    next.push_back(std::move(local));
                }
            }
        }

        for (int i = 0; i < count && ValidAddr(list); i++) {
            uint64_t actor = d.Read<uint64_t>(list + i * o.entityStride);
            if (!ValidAddr(actor)) continue;

            KzPlayer p;
            p.actor = actor;
            if (!ReadActorOrigin(d, actor, p.feet)) continue;
            p.head     = { p.feet.x, p.feet.y, p.feet.z + o.headHeight };
            p.team     = d.Read<int>(actor + o.teamId);
            p.health   = ReadActorHealth(d, actor);
            p.alive    = p.health > 0;
            p.isLocal  = (localTeam >= 0 && p.team == localTeam && next.size() == 1);

            float dx = p.feet.x - cam.origin.x,
                  dy = p.feet.y - cam.origin.y,
                  dz = p.feet.z - cam.origin.z;
            p.distance = std::sqrt(dx*dx + dy*dy + dz*dz);
            p.onScreen = WorldToScreen(cam, p.feet, p.sx, p.sy, screenW, screenH);
            UpdateTrail(p, s_players, cam, screenW, screenH);
            next.push_back(std::move(p));
        }
    }

    {
        std::lock_guard<std::mutex> l(s_mtx);
        s_players.swap(next);
        s_camera = cam;
        s_localTeam = localTeam;
    }
    return cam.valid;
}

const std::vector<KzPlayer>& Players() { return s_players; }
const KzCamera& Camera()               { return s_camera; }
int LocalTeam()                        { return s_localTeam; }

} // namespace kz
