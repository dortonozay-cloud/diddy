#pragma once
// KZ offsets — fallback statics. Runtime scanner overrides these on startup.
#include <cstdint>

struct KzOffsets {
    uint64_t gameManagerRva  = 0x11216582;
    int      pointerShift    = 12;

    uint64_t entityList      = 0x98;
    uint64_t entityCount     = 0xA0;
    uint64_t entityStride    = 0x8;

    uint64_t uworldRva       = 0x10AEC0B8;
    uint64_t gameInstance    = 0x1B8;
    uint64_t localPlayers    = 0x38;
    uint64_t playerController= 0x30;
    uint64_t localPawn       = 0x338;

    uint64_t teamId          = 0x10E0;
    uint64_t health0         = 0x18;
    uint64_t health1         = 0xD8;
    uint64_t health2         = 0x08;
    uint64_t health3         = 0x1BC;

    uint64_t plainPos[2]     = { 0x50, 0x60 };
    uint64_t encRoots[2]     = { 0x20, 0x30 };
    uint64_t encNodeOff[2]   = { 0x30, 0x00 };

    uint64_t viewTransformRva   = 0xE49C7E0;
    uint64_t projectionMatrix   = 0x250;
    uint64_t cameraOrigin       = 0x190;

    float headHeight   = 1.62f;
    float neckHeight   = 1.45f;
    float chestHeight  = 1.25f;
    float pelvisHeight = 0.95f;
    float bodyHeight   = 1.72f;
};

inline KzOffsets g_offsets;
