// ============================================================================
// KZ Pattern Scanner — R6 Siege, build 2026-09-13
//
// Uses ReadProcessMemory once at startup to copy .text into a heap buffer,
// scans for current signatures, updates g_offsets, then frees the buffer.
// All subsequent reads go through the driver.
//
// Patterns sourced from the 2026-09-13 offset dump.
// ============================================================================

#include "scanner.h"
#include "offsets.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <string>
#include <sstream>
#include <psapi.h>

#pragma comment(lib, "psapi.lib")

namespace kz {

struct PatByte { uint8_t val; bool wild; };

static std::vector<PatByte> ParsePattern(const char* pat) {
    std::vector<PatByte> out;
    std::istringstream ss(pat);
    std::string tok;
    while (ss >> tok) {
        PatByte pb{};
        if (tok == "?" || tok == "??") { pb.wild = true; }
        else { pb.val = (uint8_t)strtoul(tok.c_str(), nullptr, 16); }
        out.push_back(pb);
    }
    return out;
}

static size_t ScanBuf(const uint8_t* buf, size_t len,
                      const std::vector<PatByte>& pat) {
    if (pat.empty() || len < pat.size()) return SIZE_MAX;
    size_t last = len - pat.size();
    for (size_t i = 0; i <= last; i++) {
        bool ok = true;
        for (size_t j = 0; j < pat.size(); j++)
            if (!pat[j].wild && buf[i+j] != pat[j].val) { ok=false; break; }
        if (ok) return i;
    }
    return SIZE_MAX;
}

static uint64_t ResolveRip(uint64_t instrVA, int rel32Off, int instrLen,
                            const uint8_t* b) {
    return instrVA + instrLen + *(int32_t*)(b + rel32Off);
}

struct Section { uint8_t* buf=nullptr; size_t size=0; uint64_t baseVA=0; };

static Section ReadSection(HANDLE proc, uint64_t modBase, const char* name) {
    Section s{};
    IMAGE_DOS_HEADER dos{}; SIZE_T rb=0;
    if (!ReadProcessMemory(proc,(LPCVOID)modBase,&dos,sizeof(dos),&rb)) return s;
    IMAGE_NT_HEADERS64 nth{};
    if (!ReadProcessMemory(proc,(LPCVOID)(modBase+dos.e_lfanew),&nth,sizeof(nth),&rb)) return s;
    uint64_t tbl = modBase + dos.e_lfanew + sizeof(nth);
    for (uint32_t i=0; i<nth.FileHeader.NumberOfSections; i++) {
        IMAGE_SECTION_HEADER sh{};
        if (!ReadProcessMemory(proc,(LPCVOID)(tbl+i*sizeof(sh)),&sh,sizeof(sh),&rb)) continue;
        char sn[9]{}; memcpy(sn,sh.Name,8);
        if (strncmp(sn,name,8)!=0) continue;
        s.size=sh.Misc.VirtualSize; s.baseVA=modBase+sh.VirtualAddress;
        s.buf=(uint8_t*)malloc(s.size);
        if (!s.buf){s.size=0;return s;}
        if (!ReadProcessMemory(proc,(LPCVOID)s.baseVA,s.buf,s.size,&rb))
            {free(s.buf);s.buf=nullptr;s.size=0;}
        return s;
    }
    return s;
}

// ============================================================================
// GameManager
// Dump pattern: "48 8B 0D ?? ?? ?? ?? 48 85 C9 0F 84 ?? ?? ?? ?? 48 8B 01 FF 90 90 00 00 00"
// Also try short variant: "48 8B 0D ?? ?? ?? ?? 48 85 C9 0F 84 ?? ?? ?? ?? 48 8B 01 FF 90"
// RIP-relative at +3, instrLen=7 → pointer to GameManager singleton
// ============================================================================
static bool FindGameManager(const Section& text, uint64_t modBase,
                            uint64_t& rvaOut, int& shiftOut) {
    // Primary: from dump — full sequence including FF 90 90 00 00 00
    const char* pats[] = {
        "48 8B 0D ?? ?? ?? ?? 48 85 C9 0F 84 ?? ?? ?? ?? 48 8B 01 FF 90 90 00 00 00",
        "48 8B 0D ?? ?? ?? ?? 48 85 C9 0F 84 ?? ?? ?? ?? 48 8B 01 FF 90",
        // fallback with SHR12 shift pattern
        "48 8B 05 ? ? ? ? 48 C1 E8 0C",
        "48 8B 05 ? ? ? ? 48 C1 F8 0C",
    };
    for (auto* p : pats) {
        auto pat = ParsePattern(p);
        size_t off = ScanBuf(text.buf, text.size, pat);
        if (off == SIZE_MAX) continue;
        uint64_t instrVA  = text.baseVA + off;
        uint64_t targetVA = ResolveRip(instrVA, 3, 7, text.buf + off);
        rvaOut   = targetVA - modBase;
        // SHR12 patterns compress the pointer; the 48 8B 0D ones don't
        shiftOut = (strstr(p, "C1 E8") || strstr(p, "C1 F8")) ? 12 : 0;
        return true;
    }
    return false;
}

// ============================================================================
// ViewTransform / camera block
// Dump gives ViewMatrixAddress RVA = 0x11FB8EF0, ViewBlock cam_pos=+0x190 vp_matrix=+0x250
// Patterns: camera_one and camera_two from dump
// "48 8B 0D ?? ?? ?? ?? 4C 8B 01 41 FF 90 D8 00 00 00 F3 0F 10"
// "48 8B 0D ?? ?? ?? ?? 48 8B 01 FF 90 D8 00 00 00 F3 0F 10"
// RIP-relative at +3, instrLen=7
// ============================================================================
static bool FindViewTransform(const Section& text, uint64_t modBase,
                              uint64_t& rvaOut) {
    const char* pats[] = {
        "48 8B 0D ?? ?? ?? ?? 4C 8B 01 41 FF 90 D8 00 00 00 F3 0F 10",
        "48 8B 0D ?? ?? ?? ?? 48 8B 01 FF 90 D8 00 00 00 F3 0F 10",
        // View_matrix pattern from dump
        "48 8B 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 90 48 83 C4 58 41 5D 41 5C 41 5F 5E 5B 5F 5D",
        // generic fallbacks
        "0F 28 ? ? 48 8D 0D ? ? ? ?",
        "48 8D 15 ? ? ? ? 48 8B CF",
    };
    for (int i = 0; i < 5; i++) {
        auto pat = ParsePattern(pats[i]);
        size_t off = ScanBuf(text.buf, text.size, pat);
        if (off == SIZE_MAX) continue;
        uint64_t instrVA  = text.baseVA + off;
        // patterns 0-2: MOV rcx,[rip+rel32] — rel32 at +3, len 7
        // pattern 3: MOVAPS+LEA — LEA at +4 from match
        // pattern 4: LEA rdx at +0, rel32 at +3
        int rel32off = 3, instrlen = 7;
        if (i == 3) { instrVA += 4; }  // skip MOVAPS prefix
        uint64_t targetVA = ResolveRip(instrVA, rel32off, instrlen, text.buf + (instrVA - text.baseVA));
        rvaOut = targetVA - modBase;
        return true;
    }
    return false;
}

// ============================================================================
// Entity system
// From dump: entity pattern "FF 91 E0 00 00 00 8B B8 10 01 00 00"
// This is a CALL [rcx+0xE0] followed by MOV edi,[rax+0x110]
// The entityList offset = 0xE0 (vtable slot), entityCount at +0x110
// Also try the generic MOV pair scan
// ============================================================================
static bool FindEntityOffsets(const Section& text,
                              uint64_t& listOff, uint64_t& countOff) {
    // Primary: exact dump pattern
    auto pat = ParsePattern("FF 91 E0 00 00 00 8B B8 10 01 00 00");
    size_t off = ScanBuf(text.buf, text.size, pat);
    if (off != SIZE_MAX) {
        // CALL [rcx+imm32] → imm32 at +2 is the vtable offset (entity list)
        listOff  = *(uint32_t*)(text.buf + off + 2);
        // MOV edi,[rax+imm32] → imm32 at +8
        countOff = *(uint32_t*)(text.buf + off + 8);
        return true;
    }
    // Fallback: generic pair
    pat = ParsePattern("48 8B 88 ? ? ? ? 8B 80 ? ? ? ?");
    off = ScanBuf(text.buf, text.size, pat);
    if (off != SIZE_MAX) {
        listOff  = *(uint32_t*)(text.buf + off + 3);
        countOff = *(uint32_t*)(text.buf + off + 10);
        return true;
    }
    return false;
}

// TeamId: generic — unchanged, still valid
static bool FindTeamId(const Section& text, uint64_t& teamIdOff) {
    auto pat = ParsePattern("0F B6 80 ? ? ? ? 83 F8 60");
    size_t off = ScanBuf(text.buf, text.size, pat);
    if (off == SIZE_MAX) return false;
    teamIdOff = *(uint32_t*)(text.buf + off + 3);
    return true;
}

// UWorld — generic, unchanged
static bool FindUWorld(const Section& text, uint64_t modBase, uint64_t& rvaOut) {
    const char* pats[] = {
        "48 8B 1D ? ? ? ? 90 90",
        "48 8B 05 ? ? ? ? 48 89 41 ? 48 85 C0",
    };
    for (auto* p : pats) {
        auto pat = ParsePattern(p);
        size_t off = ScanBuf(text.buf, text.size, pat);
        if (off == SIZE_MAX) continue;
        uint64_t instrVA  = text.baseVA + off;
        uint64_t targetVA = ResolveRip(instrVA, 3, 7, text.buf + off);
        rvaOut = targetVA - modBase;
        return true;
    }
    return false;
}

// Health chain — unchanged
static bool FindHealthChain(const Section& text, KzOffsets& o) {
    auto pat = ParsePattern("48 8B 40 ? 48 8B 40 ? 48 8B 80 ? ? ? ?");
    size_t off = ScanBuf(text.buf, text.size, pat);
    if (off == SIZE_MAX) return false;
    o.health0 = text.buf[off + 3];
    o.health1 = text.buf[off + 7];
    o.health2 = *(uint32_t*)(text.buf + off + 10);
    size_t search = (off + 14 + 32 < text.size) ? 32 : 0;
    for (size_t k = off+14; k < off+14+search; k++) {
        if (text.buf[k]==0x8B && (text.buf[k+1]==0x88||text.buf[k+1]==0x80)) {
            o.health3 = *(uint32_t*)(text.buf + k + 2);
            return true;
        }
    }
    return true;
}

// ============================================================================
// Also seed the static fallback values from the dump if scan misses
// ============================================================================
static void SeedDumpStatics() {
    // From 2026-09-13 dump — RVAs relative to Base 0x7FF66C070000
    // ActorMovAddress RVA = 0x00CFCE57 — this is the GameManager write
    // ViewMatrixAddress RVA = 0x11FB8EF0 — view block
    // These are used if the scanner misses
    if (g_offsets.gameManagerRva  == 0x11216582)
        g_offsets.gameManagerRva  = 0x00CFCE57;
    if (g_offsets.viewTransformRva == 0xE49C7E0)
        g_offsets.viewTransformRva = 0x11FB8EF0;
    // ViewBlock offsets confirmed in dump: cam_pos=+0x190, vp_matrix=+0x250
    g_offsets.projectionMatrix = 0x250;
    g_offsets.cameraOrigin     = 0x190;
}

bool ScanOffsets(uint64_t gameBase, DWORD pid) {
    printf("[scan] opening process...\n");
    HANDLE proc = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION,
                              FALSE, pid);
    if (!proc) {
        printf("[scan] OpenProcess failed (%lu) — seeding dump statics\n",
               GetLastError());
        SeedDumpStatics();
        return false;
    }

    printf("[scan] reading .text...\n");
    Section text = ReadSection(proc, gameBase, ".text");
    CloseHandle(proc);

    if (!text.buf) {
        printf("[scan] .text read failed — seeding dump statics\n");
        SeedDumpStatics();
        return false;
    }

    printf("[scan] .text @ 0x%llX  size 0x%zX\n",
           (unsigned long long)text.baseVA, text.size);

    // Seed dump statics first as baseline, scanner overrides per-sig
    SeedDumpStatics();

    int found=0, total=6;

    uint64_t gmRva=0; int shift=0;
    if (FindGameManager(text, gameBase, gmRva, shift)) {
        g_offsets.gameManagerRva = gmRva;
        g_offsets.pointerShift   = shift;
        printf("[scan] GameManager  = 0x%llX (shift %d)\n",
               (unsigned long long)gmRva, shift);
        found++;
    } else printf("[scan] GameManager: sig miss — using dump static 0x%llX\n",
                  (unsigned long long)g_offsets.gameManagerRva);

    uint64_t vtRva=0;
    if (FindViewTransform(text, gameBase, vtRva)) {
        g_offsets.viewTransformRva = vtRva;
        printf("[scan] ViewTransform = 0x%llX\n", (unsigned long long)vtRva);
        found++;
    } else printf("[scan] ViewTransform: sig miss — using 0x%llX\n",
                  (unsigned long long)g_offsets.viewTransformRva);

    uint64_t listOff=0, countOff=0;
    if (FindEntityOffsets(text, listOff, countOff)) {
        g_offsets.entityList  = listOff;
        g_offsets.entityCount = countOff;
        printf("[scan] entities list=0x%llX count=0x%llX\n",
               (unsigned long long)listOff, (unsigned long long)countOff);
        found++;
    } else printf("[scan] EntityOffsets: sig miss\n");

    uint64_t teamOff=0;
    if (FindTeamId(text, teamOff)) {
        g_offsets.teamId = teamOff;
        printf("[scan] teamId = 0x%llX\n", (unsigned long long)teamOff);
        found++;
    } else printf("[scan] TeamId: sig miss\n");

    uint64_t uwRva=0;
    if (FindUWorld(text, gameBase, uwRva)) {
        g_offsets.uworldRva = uwRva;
        printf("[scan] UWorld = 0x%llX\n", (unsigned long long)uwRva);
        found++;
    } else printf("[scan] UWorld: sig miss\n");

    if (FindHealthChain(text, g_offsets)) {
        printf("[scan] health [+0x%llX][+0x%llX][+0x%llX]+0x%llX\n",
               (unsigned long long)g_offsets.health0,
               (unsigned long long)g_offsets.health1,
               (unsigned long long)g_offsets.health2,
               (unsigned long long)g_offsets.health3);
        found++;
    } else printf("[scan] HealthChain: sig miss\n");

    free(text.buf);
    printf("[scan] %d/%d resolved\n", found, total);
    return found >= 2;
}

} // namespace kz
