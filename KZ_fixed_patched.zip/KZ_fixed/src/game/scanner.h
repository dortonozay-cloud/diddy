#pragma once
// ============================================================================
// KZ Pattern Scanner — startup offset resolution via ReadProcessMemory.
//
// On launch, after finding the PID and before entering the game loop:
//   1. OpenProcess with PROCESS_VM_READ | PROCESS_QUERY_INFORMATION
//   2. Copy the game's .text section into a local heap buffer (one RPM call)
//   3. Scan the buffer for known byte signatures
//   4. Convert matched buffer offsets back to game VAs, compute RVAs
//   5. Update g_offsets in place
//   6. Free the buffer
//
// After this returns, g_offsets has live values for this game build.
// The driver handles all subsequent memory reads — RPM is never used again.
// ============================================================================
#include <windows.h>
#include <cstdint>

namespace kz {

// Resolve all offsets for the current game build.
// gameBase  = the game module base VA (from driver or GetModuleBaseAddress)
// pid       = game process ID
// Returns true if all critical offsets were found.
bool ScanOffsets(uint64_t gameBase, DWORD pid);

} // namespace kz
