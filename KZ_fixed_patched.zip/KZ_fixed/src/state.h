#pragma once
// Runtime state set by main(), read by the menu for its status tab.
#include <windows.h>
#include <cstdint>

extern uint64_t g_gameBase;
extern DWORD    g_gamePid;
extern int      g_screenW;
extern int      g_screenH;

// --demo: preview the UI/ESP with synthetic targets, no game and no driver.
extern bool     g_demoMode;
