#pragma once
#define KZ_FULL_NAME     "KZ"
#define KZ_VERSION       "1.0.0"
#define KZ_WINDOW_TITLE  "KZ | R6 External"
#define KZ_CONFIG_FILE   "settings.ini"
