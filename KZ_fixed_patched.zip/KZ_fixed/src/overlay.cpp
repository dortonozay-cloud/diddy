// KZ overlay implementation.
#include "overlay.h"
#include "branding.h"
#include "ui/theme.h"

#include <imgui.h>
#include <imgui_impl_dx9.h>
#include <imgui_impl_win32.h>
#include <dwmapi.h>

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace kzoverlay {

static HWND s_window = nullptr;
static HWND s_game = nullptr;
static IDirect3D9Ex* s_d3d = nullptr;
static IDirect3DDevice9* s_dev = nullptr;
static D3DPRESENT_PARAMETERS s_pp{};
static int s_w = 0, s_h = 0;
static bool s_quit = false;

static void RecalcRect() {
    if (!s_game) {
        s_w = GetSystemMetrics(SM_CXSCREEN);
        s_h = GetSystemMetrics(SM_CYSCREEN);
        if (s_window) MoveWindow(s_window, 0, 0, s_w, s_h, TRUE);
        return;
    }
    RECT r{};
    GetWindowRect(s_game, &r);
    int w = r.right - r.left, h = r.bottom - r.top;
    DWORD style = GetWindowLong(s_game, GWL_STYLE);
    if (style & WS_BORDER) { r.top += 32; h -= 39; }
    s_w = w; s_h = h;
    if (s_window) MoveWindow(s_window, r.left, r.top, w, h, TRUE);
}

static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    if (ImGui_ImplWin32_WndProcHandler(h, msg, w, l)) return true;
    switch (msg) {
    case WM_DESTROY:
        s_quit = true;
        PostQuitMessage(0);
        return 0;
    case WM_SIZE:
        if (s_dev && w != SIZE_MINIMIZED) {
            ImGui_ImplDX9_InvalidateDeviceObjects();
            s_pp.BackBufferWidth = (UINT)LOWORD(l);
            s_pp.BackBufferHeight = (UINT)HIWORD(l);
            if (s_dev->Reset(&s_pp) == D3D_OK)
                ImGui_ImplDX9_CreateDeviceObjects();
        }
        return 0;
    }
    return DefWindowProcA(h, msg, w, l);
}

bool Init() {
    WNDCLASSA wc{};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandleA(nullptr);
    wc.lpszClassName = "KZOverlay";
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassA(&wc);

    s_window = CreateWindowA("KZOverlay", KZ_WINDOW_TITLE, WS_POPUP, 0, 0,
                             GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
                             nullptr, nullptr, wc.hInstance, nullptr);
    if (!s_window) return false;
    ShowWindow(s_window, SW_SHOW);
    UpdateWindow(s_window);

    if (FAILED(Direct3DCreate9Ex(D3D_SDK_VERSION, &s_d3d))) return false;
    ZeroMemory(&s_pp, sizeof(s_pp));
    s_pp.BackBufferWidth = GetSystemMetrics(SM_CXSCREEN);
    s_pp.BackBufferHeight = GetSystemMetrics(SM_CYSCREEN);
    s_pp.BackBufferFormat = D3DFMT_A8R8G8B8;
    s_pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    s_pp.hDeviceWindow = s_window;
    s_pp.Windowed = TRUE;
    s_pp.EnableAutoDepthStencil = TRUE;
    s_pp.AutoDepthStencilFormat = D3DFMT_D16;
    s_pp.PresentationInterval = D3DPRESENT_INTERVAL_ONE;
    if (FAILED(s_d3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, s_window,
                                   D3DCREATE_SOFTWARE_VERTEXPROCESSING, &s_pp, &s_dev))) {
        s_d3d->Release(); s_d3d = nullptr;
        return false;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui_ImplWin32_Init(s_window);
    ImGui_ImplDX9_Init(s_dev);
    ApplyKzTheme();
    return true;
}

void SetGameWindow(HWND game) {
    s_game = game;
    RecalcRect();
}

void SetClickThrough(bool on) {
    if (!s_window) return;
    LONG ex = WS_EX_TOOLWINDOW | WS_EX_LAYERED;
    if (on) ex |= WS_EX_TRANSPARENT;
    SetWindowLong(s_window, GWL_EXSTYLE, ex);
}

bool BeginFrame() {
    MSG msg{};
    while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
        if (msg.message == WM_QUIT) s_quit = true;
    }
    if (s_quit || (s_game && !IsWindow(s_game))) return false;
    RecalcRect();

    ImGui_ImplDX9_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    ImGuiIO& io = ImGui::GetIO();
    POINT p{};
    GetCursorPos(&p);
    RECT r{};
    GetWindowRect(s_window, &r);
    io.MousePos = ImVec2((float)(p.x - r.left), (float)(p.y - r.top));
    io.MouseDown[0] = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    return true;
}

void EndFrame() {
    ImGui::EndFrame();
    ImGui::Render();
    s_dev->SetRenderState(D3DRS_ZENABLE, FALSE);
    s_dev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    s_dev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    s_dev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    s_dev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
    s_dev->Clear(0, nullptr, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 0, 0, 0), 1.f, 0);
    if (SUCCEEDED(s_dev->BeginScene())) {
        ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
        s_dev->EndScene();
    }
    HRESULT hr = s_dev->Present(nullptr, nullptr, nullptr, nullptr);
    if (hr == D3DERR_DEVICELOST && s_dev->TestCooperativeLevel() == D3DERR_DEVICENOTRESET) {
        ImGui_ImplDX9_InvalidateDeviceObjects();
        s_dev->Reset(&s_pp);
        ImGui_ImplDX9_CreateDeviceObjects();
    }
}

IDirect3DDevice9* Device() { return s_dev; }
void GetSize(int& w, int& h) { w = s_w; h = s_h; }

void Shutdown() {
    ImGui_ImplDX9_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    if (s_dev) s_dev->Release();
    if (s_d3d) s_d3d->Release();
    if (s_window) DestroyWindow(s_window);
    s_dev = nullptr; s_d3d = nullptr; s_window = nullptr;
}

} // namespace kzoverlay
