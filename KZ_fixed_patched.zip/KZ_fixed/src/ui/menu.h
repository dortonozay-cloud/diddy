#pragma once
// KZ menu. Deliberately plain: the layout is a starting point the owner will
// restyle; all state lives in g_settings so reworking the UI is safe.
#include <d3d9.h>

namespace kzui {
bool Init(IDirect3DDevice9* device);      // builds logo texture
void Shutdown();
void Render(bool& open);                  // draws the menu window when open
}
