// KZ UI theme implementation (Dear ImGui styling).
#include "theme.h"
#include <imgui.h>

void ApplyKzTheme() {
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = 10.f;
    st.FrameRounding = 5.f;
    st.GrabRounding = 4.f;
    st.PopupRounding = 6.f;
    st.ScrollbarRounding = 6.f;
    st.ChildRounding = 8.f;
    st.TabRounding = 5.f;
    st.WindowPadding = ImVec2(12, 12);
    st.FramePadding = ImVec2(8, 5);
    st.ItemSpacing = ImVec2(8, 7);
    st.WindowBorderSize = 1.f;
    st.FrameBorderSize = 0.f;

    ImVec4* c = st.Colors;
    const ImVec4 black   = ImVec4(0.02f, 0.02f, 0.02f, 0.98f);
    const ImVec4 panel   = ImVec4(0.06f, 0.06f, 0.07f, 1.00f);
    const ImVec4 panel2  = ImVec4(0.10f, 0.10f, 0.11f, 1.00f);
    const ImVec4 silver  = ImVec4(0.80f, 0.81f, 0.83f, 1.00f);
    const ImVec4 silverD = ImVec4(0.55f, 0.56f, 0.58f, 1.00f);
    const ImVec4 white   = ImVec4(0.95f, 0.95f, 0.96f, 1.00f);

    c[ImGuiCol_Text]             = white;
    c[ImGuiCol_TextDisabled]     = silverD;
    c[ImGuiCol_WindowBg]         = black;
    c[ImGuiCol_ChildBg]          = panel;
    c[ImGuiCol_PopupBg]          = panel;
    c[ImGuiCol_Border]           = ImVec4(0.35f, 0.35f, 0.37f, 0.6f);
    c[ImGuiCol_FrameBg]          = panel2;
    c[ImGuiCol_FrameBgHovered]   = ImVec4(0.16f, 0.16f, 0.18f, 1.f);
    c[ImGuiCol_FrameBgActive]    = ImVec4(0.20f, 0.20f, 0.22f, 1.f);
    c[ImGuiCol_TitleBg]          = black;
    c[ImGuiCol_TitleBgActive]    = black;
    c[ImGuiCol_TitleBgCollapsed] = black;
    c[ImGuiCol_MenuBarBg]        = panel;
    c[ImGuiCol_ScrollbarBg]      = black;
    c[ImGuiCol_ScrollbarGrab]    = silverD;
    c[ImGuiCol_CheckMark]        = silver;
    c[ImGuiCol_SliderGrab]       = silver;
    c[ImGuiCol_SliderGrabActive] = white;
    c[ImGuiCol_Button]           = panel2;
    c[ImGuiCol_ButtonHovered]    = ImVec4(0.22f, 0.22f, 0.24f, 1.f);
    c[ImGuiCol_ButtonActive]     = ImVec4(0.30f, 0.30f, 0.32f, 1.f);
    c[ImGuiCol_Header]           = panel2;
    c[ImGuiCol_HeaderHovered]    = ImVec4(0.22f, 0.22f, 0.24f, 1.f);
    c[ImGuiCol_HeaderActive]     = ImVec4(0.30f, 0.30f, 0.32f, 1.f);
    c[ImGuiCol_Separator]        = ImVec4(0.25f, 0.25f, 0.27f, 0.7f);
    c[ImGuiCol_ResizeGrip]       = ImVec4(0.8f, 0.8f, 0.82f, 0.2f);
    c[ImGuiCol_Tab]              = panel;
    c[ImGuiCol_TabHovered]       = panel2;
    c[ImGuiCol_TabActive]        = panel2;
    c[ImGuiCol_TextSelectedBg]   = ImVec4(0.8f, 0.8f, 0.82f, 0.25f);
}
