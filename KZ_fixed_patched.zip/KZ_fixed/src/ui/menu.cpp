// KZ menu implementation.
#include "menu.h"
#include "theme.h"
#include "../branding.h"
#include "../core/config.h"
#include "../core/driver.h"
#include "../game/entities.h"
#include "../kz_logo.h"
#include "../state.h"

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

#include <imgui.h>
#include <cstdio>

static LPDIRECT3DTEXTURE9 s_logoTex = nullptr;
static int s_logoW = 0, s_logoH = 0;
static int s_tab = 0;
static int s_captureAimKey = 0;

namespace kzui {

bool Init(IDirect3DDevice9* dev) {
    if (!dev) return false;
    int w = 0, h = 0, n = 0;
    unsigned char* px = stbi_load_from_memory(kz_logo_png, (int)sizeof(kz_logo_png), &w, &h, &n, 4);
    if (!px) return false;

    if (dev->CreateTexture(w, h, 1, D3DUSAGE_DYNAMIC, D3DFMT_A8R8G8B8,
                           D3DPOOL_DEFAULT, &s_logoTex, nullptr) != D3D_OK) {
        stbi_image_free(px);
        return false;
    }
    D3DLOCKED_RECT lr;
    if (s_logoTex->LockRect(0, &lr, nullptr, D3DLOCK_DISCARD) == D3D_OK) {
        for (int y = 0; y < h; y++) {
            unsigned char* dst = (unsigned char*)lr.pBits + y * lr.Pitch;
            const unsigned char* src = px + y * w * 4;
            for (int x = 0; x < w; x++) {
                dst[x*4+0] = src[x*4+2];
                dst[x*4+1] = src[x*4+1];
                dst[x*4+2] = src[x*4+0];
                dst[x*4+3] = src[x*4+3];
            }
        }
        s_logoTex->UnlockRect(0);
    }
    stbi_image_free(px);
    s_logoW = w; s_logoH = h;
    return true;
}

void Shutdown() {
    if (s_logoTex) { s_logoTex->Release(); s_logoTex = nullptr; }
}

static void TabButton(const char* label, int id) {
    bool active = (s_tab == id);
    if (active) {
        ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.22f, 0.22f, 0.24f, 1.f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.26f, 0.26f, 0.28f, 1.f));
    }
    if (ImGui::Button(label, ImVec2(140, 30))) s_tab = id;
    if (active) ImGui::PopStyleColor(2);
}

static void AimTab() {
    ImGui::Checkbox("Enable Aimbot", &g_settings.aimEnabled);
    ImGui::SliderFloat("FOV (px)",    &g_settings.aimFov,    20.f,  800.f, "%.0f");
    ImGui::SliderFloat("Smoothness",  &g_settings.aimSmooth,  1.f,   20.f, "%.1f");
    const char* bones[] = { "Head", "Neck", "Chest", "Pelvis" };
    ImGui::Combo("Bone", &g_settings.aimBone, bones, 4);
    ImGui::Checkbox("Team Check", &g_settings.aimTeamCheck);

    ImGui::Separator();
    ImGui::TextDisabled("Aim key");
    ImGui::SameLine();
    if (s_captureAimKey) {
        ImGui::Button("press a key...", ImVec2(140, 24));
        for (int vk = 1; vk < 256; vk++) {
            if (GetAsyncKeyState(vk) & 0x8000) { g_settings.aimKey = vk; s_captureAimKey = 0; break; }
        }
    } else {
        char label[64];
        snprintf(label, sizeof(label), g_settings.aimKey ? "key 0x%02X" : "always", g_settings.aimKey);
        if (ImGui::Button(label, ImVec2(140, 24))) s_captureAimKey = 1;
    }

    ImGui::Separator();
    ImGui::Checkbox("FOV circle", &g_settings.fovCircle);
    ImGui::SameLine();
    ImGui::Checkbox("FOV square", &g_settings.fovSquare);
    if (g_settings.fovCircle) g_settings.fovSquare = false;
    if (g_settings.fovSquare) g_settings.fovCircle = false;
    ImGui::ColorEdit4("FOV color", &g_settings.fovColor.r, ImGuiColorEditFlags_AlphaBar);
    ImGui::Checkbox("Crosshair", &g_settings.crosshair);
    ImGui::ColorEdit4("Crosshair color", &g_settings.crosshairColor.r, ImGuiColorEditFlags_AlphaBar);
    ImGui::SliderFloat("Crosshair size", &g_settings.crosshairSize, 3.f, 30.f, "%.0f");
}

static void EspTab() {
    // ---- Box ----
    ImGui::Checkbox("Box", &g_settings.espBox);
    ImGui::SameLine();
    ImGui::Checkbox("Cornered", &g_settings.espBoxCorner);
    ImGui::SameLine();
    ImGui::Checkbox("Filled", &g_settings.espBoxFill);
    ImGui::ColorEdit4("Box color", &g_settings.boxColor.r, ImGuiColorEditFlags_AlphaBar);
    ImGui::SliderFloat("Box thickness", &g_settings.boxThickness, 0.5f, 5.f, "%.1f");

    ImGui::Separator();

    // ---- Snaplines ----
    ImGui::Checkbox("Snaplines", &g_settings.espSnapline);
    const char* origins[] = { "Bottom", "Center", "Top" };
    ImGui::Combo("Origin", &g_settings.snapOrigin, origins, 3);
    ImGui::ColorEdit4("Snapline color", &g_settings.snapColor.r, ImGuiColorEditFlags_AlphaBar);

    ImGui::Separator();

    // ---- Skeleton ----
    ImGui::Checkbox("Skeleton", &g_settings.espSkeleton);
    if (g_settings.espSkeleton) {
        ImGui::ColorEdit4("Skeleton color",     &g_settings.skelColor.r, ImGuiColorEditFlags_AlphaBar);
        ImGui::SliderFloat("Skeleton thickness", &g_settings.skelThickness, 0.5f, 4.f, "%.1f");
    }

    ImGui::Separator();

    // ---- Trail ----
    ImGui::Checkbox("Trail ESP", &g_settings.espTrail);
    if (g_settings.espTrail) {
        ImGui::ColorEdit4("Trail color",       &g_settings.trailColor.r, ImGuiColorEditFlags_AlphaBar);
        ImGui::SliderFloat("Trail thickness",   &g_settings.trailThickness, 0.5f, 6.f, "%.1f");
        ImGui::TextDisabled("Trail fades over ~0.8s");
    }

    ImGui::Separator();

    // ---- Other ----
    ImGui::Checkbox("Distance",    &g_settings.espDistance);
    ImGui::Checkbox("Team check",  &g_settings.espTeamCheck);
    ImGui::SameLine();
    ImGui::Checkbox("Death check", &g_settings.espDeathCheck);
    ImGui::SliderInt("Render distance (m)", &g_settings.renderDist, 20, 500);
}

static void ColorsTab() {
    ImGui::Checkbox("Rainbow mode", &g_settings.rainbowMode);
    ImGui::Separator();
    ImGui::ColorEdit4("Box",        &g_settings.boxColor.r,       ImGuiColorEditFlags_AlphaBar);
    ImGui::ColorEdit4("Box fill",   &g_settings.boxFillColor.r,   ImGuiColorEditFlags_AlphaBar);
    ImGui::ColorEdit4("Snaplines",  &g_settings.snapColor.r,       ImGuiColorEditFlags_AlphaBar);
    ImGui::ColorEdit4("Distance",   &g_settings.distColor.r,       ImGuiColorEditFlags_AlphaBar);
    ImGui::ColorEdit4("Skeleton",   &g_settings.skelColor.r,       ImGuiColorEditFlags_AlphaBar);
    ImGui::ColorEdit4("Trail",      &g_settings.trailColor.r,      ImGuiColorEditFlags_AlphaBar);
    ImGui::ColorEdit4("FOV",        &g_settings.fovColor.r,        ImGuiColorEditFlags_AlphaBar);
    ImGui::ColorEdit4("Crosshair",  &g_settings.crosshairColor.r,  ImGuiColorEditFlags_AlphaBar);
}

static void MiscTab() {
    ImGui::Text(KZ_FULL_NAME " v" KZ_VERSION);
    ImGui::Separator();
    ImGui::Text("PID:    %lu",  (unsigned long)g_gamePid);
    ImGui::Text("Base:   0x%llX", (unsigned long long)g_gameBase);
    ImGui::Text("Driver: %s", (g_driver && g_driver->Available()) ? "connected" : "not loaded");
    if (g_demoMode)
        ImGui::TextColored(ImVec4(1.f, .78f, .2f, 1.f),
                           "DEMO MODE - synthetic data, aim disabled");
    ImGui::Text("Targets: %d",     (int)kz::Players().size());
    ImGui::Text("Screen:  %dx%d",  g_screenW, g_screenH);
    ImGui::Separator();
    if (ImGui::Button("Save settings", ImVec2(160, 26))) g_settings.Save();
    ImGui::SameLine();
    if (ImGui::Button("Load settings", ImVec2(160, 26))) g_settings.Load();
    ImGui::Separator();
    ImGui::TextDisabled("Offsets: src/game/offsets.h");
    ImGui::TextDisabled("Update offsets after game patches.");
}

void Render(bool& open) {
    ImGui::SetNextWindowSize(ImVec2(680, 500), ImGuiCond_FirstUseEver);
    ImGui::Begin(KZ_WINDOW_TITLE, &open,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar);

    // ---- header ----
    if (s_logoTex) {
        const float sz = 56.f;
        ImGui::Image((ImTextureID)s_logoTex, ImVec2(sz, sz));
        ImGui::SameLine(0, 12);
    }
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 8);
    ImGui::Text(KZ_FULL_NAME);
    ImGui::SameLine();
    ImGui::TextDisabled("v" KZ_VERSION);

    ImGui::Separator();

    // ---- sidebar ----
    ImGui::BeginChild("##nav", ImVec2(150, 0), true);
    TabButton("Aimbot", 0);
    TabButton("ESP",    1);
    TabButton("Colors", 2);
    TabButton("Misc",   3);
    ImGui::EndChild();

    ImGui::SameLine();
    ImGui::BeginChild("##content", ImVec2(0, 0), true);
    if      (s_tab == 0) AimTab();
    else if (s_tab == 1) EspTab();
    else if (s_tab == 2) ColorsTab();
    else                 MiscTab();
    ImGui::EndChild();

    ImGui::Separator();
    ImGui::TextDisabled("INSERT - menu | END - unload");

    ImGui::End();
}

} // namespace kzui
