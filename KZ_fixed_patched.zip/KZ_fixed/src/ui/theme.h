#pragma once
// KZ UI theme: black / brushed-silver palette matching the KZ logo.
void ApplyKzTheme();
