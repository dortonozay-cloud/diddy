#pragma once
// KZ overlay: transparent DirectX9 + Dear ImGui window layered over the game.
#include <windows.h>
#include <d3d9.h>

namespace kzoverlay {

bool Init();                       // window + device + ImGui context
void Shutdown();
void SetGameWindow(HWND game);     // overlay follows this window's rect
void SetClickThrough(bool on);     // true = input passes to the game
bool BeginFrame();                 // pump messages + start ImGui frame; false => quit
void EndFrame();                   // render + present
IDirect3DDevice9* Device();
void GetSize(int& w, int& h);

} // namespace kzoverlay
