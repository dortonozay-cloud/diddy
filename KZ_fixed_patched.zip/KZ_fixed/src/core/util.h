#pragma once
// ============================================================================
// Small shared helpers: process lookup, path helpers.
// ============================================================================
#include <windows.h>
#include <tlhelp32.h>
#include <shlobj.h>
#include <cstdint>
#include <string>
#include "../branding.h"

namespace kz {

inline DWORD FindProcessId(const char* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32 pe{};
    pe.dwSize = sizeof(pe);
    DWORD pid = 0;
    if (Process32First(snap, &pe)) {
        do {
            if (_stricmp(pe.szExeFile, name) == 0) { pid = pe.th32ProcessID; break; }
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

inline HWND FindGameWindow() {
    static const char* titles[] = {
        "Rainbow Six", "R6Game", "RainbowSix",
        "Tom Clancy's Rainbow Six  Siege", "Tom Clancy's Rainbow Six Siege",
    };
    for (const char* t : titles) {
        HWND h = FindWindowA(nullptr, t);
        if (h) return h;
    }
    return nullptr;
}

// %APPDATA%\KZ  (created if missing)
inline std::string ConfigDir() {
    char path[MAX_PATH] = {};
    std::string out = ".";
    if (SUCCEEDED(SHGetFolderPathA(nullptr, CSIDL_APPDATA, nullptr, 0, path)))
        out = path;
    out += "\\" KZ_CONFIG_DIR;
    CreateDirectoryA(out.c_str(), nullptr);
    return out;
}

} // namespace kz
