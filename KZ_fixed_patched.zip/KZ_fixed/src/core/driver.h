#pragma once
// ============================================================================
// KZ driver client — plain IOCTL client for a generic read/write driver.
//
// The IOCTL codes and request structs below match the WinDrvMgr protocol from
// the project this was rewritten from, so KZ can talk to that driver (or any
// driver implementing the same contract). KZ itself ships NO kernel driver:
// supply your own, load it yourself, and point KZ_DEVICE_NAME at it.
//
// KZ_DEVICE_NAME is stamped at build time by build_all.bat to match the
// randomised suffix the kernel driver was compiled with (__TIME__-derived).
// Do NOT edit this line manually — run build_all.bat instead.
// ============================================================================
#include <windows.h>
#include <cstdint>
#include <cstdio>

#define KZ_DEVICE_NAME L"\\.\AAAAAA"   // PATCHED BY BUILD_EVERYTHING.bat

#define KZ_IOCTL_GET_BASE     CTL_CODE(FILE_DEVICE_UNKNOWN, 0x2A2, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define KZ_IOCTL_READ_MEMORY  CTL_CODE(FILE_DEVICE_UNKNOWN, 0x2A4, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define KZ_IOCTL_WRITE_MEMORY CTL_CODE(FILE_DEVICE_UNKNOWN, 0x2A5, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define KZ_IOCTL_MOUSE_MOVE   CTL_CODE(FILE_DEVICE_UNKNOWN, 0x3A1, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)

struct KzReadRequest  { uint64_t Address; uint64_t Buffer; uint64_t Size; };
struct KzWriteRequest { uint64_t Address; uint64_t Buffer; uint64_t Size; };
struct KzBaseRequest  { int32_t  ProcessId; uint64_t BaseAddress; };   // 16 bytes, default alignment
// Wire layout matches the driver's movemouse struct: { long x; long y; unsigned short button_flags; }
struct KzMouseRequest { int32_t  X; int32_t Y; uint16_t ButtonFlags; };

class KzDriver {
public:
    ~KzDriver() { Close(); }

    bool Init(DWORD pid) {
        m_pid = pid;
        m_handle = CreateFileW(KZ_DEVICE_NAME, GENERIC_READ | GENERIC_WRITE,
                               FILE_SHARE_READ | FILE_SHARE_WRITE,
                               nullptr, OPEN_EXISTING, 0, nullptr);
        if (m_handle == INVALID_HANDLE_VALUE) {
            printf("[KZ] driver not available (err=%lu) — memory features disabled\n", GetLastError());
            return false;
        }
        printf("[KZ] driver connected\n");
        return true;
    }

    void Close() {
        if (m_handle != INVALID_HANDLE_VALUE) { CloseHandle(m_handle); m_handle = INVALID_HANDLE_VALUE; }
    }

    bool Available() const { return m_handle != INVALID_HANDLE_VALUE; }
    DWORD Pid() const { return m_pid; }

    bool ReadMemory(uint64_t addr, void* out, size_t size) {
        if (!Available()) return false;
        KzReadRequest req{ addr, (uint64_t)(uintptr_t)out, (uint64_t)size };
        DWORD bytes = 0;
        return DeviceIoControl(m_handle, KZ_IOCTL_READ_MEMORY, &req, sizeof(req),
                               nullptr, 0, &bytes, nullptr) == TRUE;
    }

    bool WriteMemory(uint64_t addr, const void* data, size_t size) {
        if (!Available()) return false;
        KzWriteRequest req{ addr, (uint64_t)(uintptr_t)data, (uint64_t)size };
        DWORD bytes = 0;
        return DeviceIoControl(m_handle, KZ_IOCTL_WRITE_MEMORY, &req, sizeof(req),
                               nullptr, 0, &bytes, nullptr) == TRUE;
    }

    template <typename T> T Read(uint64_t addr) {
        T v{};
        ReadMemory(addr, &v, sizeof(T));
        return v;
    }

    template <typename T> bool Write(uint64_t addr, const T& v) {
        return WriteMemory(addr, &v, sizeof(T));
    }

    // Driver resolves the process by PID and returns its section base address
    // (module name is not part of the wire protocol).
    uint64_t GetModuleBase() {
        if (!Available()) return 0;
        KzBaseRequest req{};
        req.ProcessId = (int32_t)m_pid;
        DWORD bytes = 0;
        if (DeviceIoControl(m_handle, KZ_IOCTL_GET_BASE, &req, sizeof(req),
                            &req, sizeof(req), &bytes, nullptr) != TRUE)
            return 0;
        return req.BaseAddress;
    }

    // Driver mouse if available, SendInput otherwise.
    void MoveMouse(int dx, int dy) {
        if (dx == 0 && dy == 0) return;
        if (Available()) {
            KzMouseRequest req{ dx, dy, 0 };
            DWORD bytes = 0;
            if (DeviceIoControl(m_handle, KZ_IOCTL_MOUSE_MOVE, &req, sizeof(req),
                                nullptr, 0, &bytes, nullptr))
                return;
        }
        INPUT in{};
        in.type = INPUT_MOUSE;
        in.mi.dx = dx;
        in.mi.dy = dy;
        in.mi.dwFlags = MOUSEEVENTF_MOVE;
        SendInput(1, &in, sizeof(in));
    }

private:
    HANDLE m_handle = INVALID_HANDLE_VALUE;
    DWORD  m_pid = 0;
};

inline KzDriver* g_driver = nullptr;   // set once in main()
