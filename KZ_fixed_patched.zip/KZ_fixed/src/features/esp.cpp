// KZ ESP rendering — box, corners, snaplines, distance, skeleton, trail.
#include "esp.h"
#include "../core/config.h"
#include "../game/entities.h"
#include "../game/offsets.h"
#include <imgui.h>
#include <cmath>

static ImU32 Col(const KzColor& c) {
    return IM_COL32((int)(c.r * 255), (int)(c.g * 255), (int)(c.b * 255), (int)(c.a * 255));
}

static ImU32 ColA(const KzColor& c, float alpha) {
    return IM_COL32((int)(c.r * 255), (int)(c.g * 255), (int)(c.b * 255), (int)(c.a * alpha * 255));
}

static ImU32 Rainbow(float alpha, float offset) {
    float h = fmodf((float)ImGui::GetTime() * 0.3f + offset, 1.0f);
    float r, g, b;
    ImGui::ColorConvertHSVtoRGB(h, 1.f, 1.f, r, g, b);
    return IM_COL32((int)(r * 255), (int)(g * 255), (int)(b * 255), (int)(alpha * 255));
}

static bool Filtered(const KzPlayer& p) {
    const KzSettings& s = g_settings;
    if (p.isLocal) return true;
    if (s.espTeamCheck  && kz::LocalTeam() >= 0 && p.team == kz::LocalTeam()) return true;
    if (s.espDeathCheck && !p.alive) return true;
    if (p.distance > (float)s.renderDist) return true;
    return false;
}

// ---------------------------------------------------------------------------
// Skeleton
// ---------------------------------------------------------------------------
// Draws a 5-joint approximation: head circle, neck→pelvis spine, arm bar at
// chest level, left/right legs from pelvis to feet.
// All points derived from the on-screen box so no extra reads are needed.
//
// Bug in old version: head circle was placed at (cx, yHead - boxH * 0.05f)
// which put it *inside* the box rect and invisible behind the box fill.
// Fix: place it at (cx, yHead) and use the correct radius that clears the top.
// ---------------------------------------------------------------------------
static void DrawSkeleton(ImDrawList* dl, const KzSettings& s,
                         float cx, float top, float bottom, float boxW,
                         float boxH, int idx) {
    const KzOffsets& o = g_offsets;

    // Map a world height (metres above feet) to a screen Y inside the box.
    // bottom = feet screen Y, top = head screen Y (top < bottom in screen space).
    auto yOf = [&](float hgt) -> float {
        float t = hgt / o.bodyHeight;
        return bottom - boxH * t;
    };

    float yHead  = yOf(o.headHeight);
    float yNeck  = yOf(o.neckHeight);
    float yChest = yOf(o.chestHeight);
    float yPelv  = yOf(o.pelvisHeight);
    float w2     = boxW * 0.5f;

    // Head circle sits *above* yHead, not overlapping the spine.
    // Radius = half the gap between the top of the box and yNeck,
    // clamped so it never exceeds 12% of boxH.
    float headRadius = std::min((yNeck - top) * 0.5f, boxH * 0.12f);
    if (headRadius < 2.f) headRadius = 2.f;
    float headCY = top + headRadius;   // centre of circle clears the top edge

    ImU32 sk = s.rainbowMode ? Rainbow(s.skelColor.a, idx * 0.17f) : Col(s.skelColor);
    float th = s.skelThickness;

    dl->AddCircle(ImVec2(cx, headCY), headRadius, sk, 12, th);          // head
    dl->AddLine(ImVec2(cx, headCY + headRadius), ImVec2(cx, yPelv), sk, th); // spine
    dl->AddLine(ImVec2(cx - w2 * .85f, yChest),
                ImVec2(cx + w2 * .85f, yChest), sk, th);                // arms
    dl->AddLine(ImVec2(cx, yPelv), ImVec2(cx - w2 * .55f, bottom), sk, th); // left leg
    dl->AddLine(ImVec2(cx, yPelv), ImVec2(cx + w2 * .55f, bottom), sk, th); // right leg
}

// ---------------------------------------------------------------------------
// Trail
// ---------------------------------------------------------------------------
// Renders stored screen-space points as a fading polyline.
// Points are stored newest-first in the deque; we draw oldest→newest so
// the newest segment is on top.
// ---------------------------------------------------------------------------
static void DrawTrail(ImDrawList* dl, const KzSettings& s,
                      const KzPlayer& p, int idx) {
    if (p.trail.size() < 2) return;

    for (int i = (int)p.trail.size() - 1; i > 0; i--) {
        const TrailPoint& a = p.trail[i];
        const TrailPoint& b = p.trail[i - 1];

        // Use the older point's alpha so the tail fades out naturally
        float alpha = a.alpha;
        if (alpha <= 0.f) continue;

        ImU32 c = s.rainbowMode
            ? Rainbow(s.trailColor.a * alpha, idx * 0.19f)
            : ColA(s.trailColor, alpha);

        dl->AddLine(ImVec2(a.x, a.y), ImVec2(b.x, b.y), c, s.trailThickness);
    }
}

// ---------------------------------------------------------------------------
// Main ESP render
// ---------------------------------------------------------------------------
void RenderEsp(int W, int H) {
    const KzSettings& s = g_settings;
    const KzCamera& cam = kz::Camera();
    if (!cam.valid) return;
    ImDrawList* dl = ImGui::GetOverlayDrawList();

    int idx = 0;
    for (const KzPlayer& p : kz::Players()) {
        if (Filtered(p)) continue;
        idx++;

        // ---- trail (drawn before box so it renders behind) ----
        if (s.espTrail)
            DrawTrail(dl, s, p, idx);

        float fx, fy, hx, hy;
        if (!kz::WorldToScreen(cam, p.feet, fx, fy, W, H)) continue;
        if (!kz::WorldToScreen(cam, p.head, hx, hy, W, H)) continue;

        float boxH = fy - hy;
        if (boxH < 4.f) continue;
        float boxW  = boxH * 0.42f;
        float top   = hy - boxH * 0.06f;
        float bottom= fy;
        float cx    = (fx + hx) * 0.5f;

        ImU32 boxCol = s.rainbowMode ? Rainbow(s.boxColor.a, idx * 0.11f) : Col(s.boxColor);

        // ---- box ----
        if (s.espBox) {
            if (s.espBoxFill)
                dl->AddRectFilled(ImVec2(cx - boxW*.5f, top), ImVec2(cx + boxW*.5f, bottom),
                                  Col(s.boxFillColor));
            if (s.espBoxCorner) {
                float cl = boxH * 0.22f;
                const ImVec2 tl(cx - boxW*.5f, top),  tr(cx + boxW*.5f, top);
                const ImVec2 bl(cx - boxW*.5f, bottom), br(cx + boxW*.5f, bottom);
                dl->AddLine(tl, ImVec2(tl.x + cl, tl.y), boxCol, s.boxThickness);
                dl->AddLine(tl, ImVec2(tl.x, tl.y + cl), boxCol, s.boxThickness);
                dl->AddLine(tr, ImVec2(tr.x - cl, tr.y), boxCol, s.boxThickness);
                dl->AddLine(tr, ImVec2(tr.x, tr.y + cl), boxCol, s.boxThickness);
                dl->AddLine(bl, ImVec2(bl.x + cl, bl.y), boxCol, s.boxThickness);
                dl->AddLine(bl, ImVec2(bl.x, bl.y - cl), boxCol, s.boxThickness);
                dl->AddLine(br, ImVec2(br.x - cl, br.y), boxCol, s.boxThickness);
                dl->AddLine(br, ImVec2(br.x, br.y - cl), boxCol, s.boxThickness);
            } else {
                dl->AddRect(ImVec2(cx - boxW*.5f, top), ImVec2(cx + boxW*.5f, bottom),
                            boxCol, 0.f, 0, s.boxThickness);
            }
        }

        // ---- snaplines ----
        if (s.espSnapline) {
            float oy = s.snapOrigin == 0 ? (float)H : s.snapOrigin == 1 ? H * .5f : 0.f;
            dl->AddLine(ImVec2(W * .5f, oy), ImVec2(cx, top + boxH * .5f),
                        s.rainbowMode ? Rainbow(s.snapColor.a, idx * 0.13f) : Col(s.snapColor),
                        s.snapThickness);
        }

        // ---- distance ----
        if (s.espDistance) {
            char buf[32];
            snprintf(buf, sizeof(buf), "%dm", (int)p.distance);
            ImVec2 ts = ImGui::CalcTextSize(buf);
            dl->AddText(ImVec2(cx - ts.x * .5f, bottom + 2.f), Col(s.distColor), buf);
        }

        // ---- skeleton ----
        if (s.espSkeleton)
            DrawSkeleton(dl, s, cx, top, bottom, boxW, boxH, idx);
    }
}
