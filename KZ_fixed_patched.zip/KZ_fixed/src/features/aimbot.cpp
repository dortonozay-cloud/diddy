// KZ aimbot implementation.
#include "aimbot.h"
#include "../core/config.h"
#include "../core/driver.h"
#include "../game/entities.h"
#include "../game/offsets.h"
#include "../state.h"
#include <cmath>

static float BoneHeight(int bone) {
    const KzOffsets& o = g_offsets;
    switch (bone) {
    case 0:  return o.headHeight;
    case 1:  return o.neckHeight;
    case 2:  return o.chestHeight;
    default: return o.pelvisHeight;
    }
}

void RunAimbot(int W, int H) {
    const KzSettings& s = g_settings;
    if (g_demoMode) return;                  // never move the real cursor in demo
    if (!s.aimEnabled || !g_driver) return;
    if (s.aimKey != 0 && !(GetAsyncKeyState(s.aimKey) & 0x8000)) return;

    const KzCamera& cam = kz::Camera();
    if (!cam.valid) return;

    float cx = W * .5f, cy = H * .5f;
    float bestDist = s.aimFov;          // pixel radius
    Vec3 bestWorld{};
    bool have = false;

    for (const KzPlayer& p : kz::Players()) {
        if (p.isLocal || !p.alive) continue;
        if (s.aimTeamCheck && kz::LocalTeam() >= 0 && p.team == kz::LocalTeam()) continue;

        Vec3 bone{ p.feet.x, p.feet.y, p.feet.z + BoneHeight(s.aimBone) };
        float sx, sy;
        if (!kz::WorldToScreen(cam, bone, sx, sy, W, H)) continue;
        float d = std::sqrt((sx - cx) * (sx - cx) + (sy - cy) * (sy - cy));
        if (d < bestDist) { bestDist = d; bestWorld = bone; have = true; }
    }

    if (!have) return;
    float sx, sy;
    if (!kz::WorldToScreen(cam, bestWorld, sx, sy, W, H)) return;

    float dx = sx - cx, dy = sy - cy;
    float smooth = s.aimSmooth < 1.f ? 1.f : s.aimSmooth;
    g_driver->MoveMouse((int)(dx / smooth), (int)(dy / smooth));
}
