#pragma once
// KZ screen visuals: crosshair + FOV indicator.
void RenderVisuals(int screenW, int screenH);
