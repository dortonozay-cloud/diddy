// KZ screen visuals implementation.
#include "visuals.h"
#include "../core/config.h"
#include <imgui.h>

static ImU32 Col(const KzColor& c) {
    return IM_COL32((int)(c.r * 255), (int)(c.g * 255), (int)(c.b * 255), (int)(c.a * 255));
}

void RenderVisuals(int W, int H) {
    const KzSettings& s = g_settings;
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    float cx = W * .5f, cy = H * .5f;

    if (s.fovCircle || s.fovSquare) {
        ImU32 c = Col(s.fovColor);
        if (s.fovCircle)
            dl->AddCircle(ImVec2(cx, cy), s.aimFov, c, 48, s.fovThickness);
        else
            dl->AddRect(ImVec2(cx - s.aimFov, cy - s.aimFov),
                        ImVec2(cx + s.aimFov, cy + s.aimFov), c, 0.f, 0, s.fovThickness);
    }

    if (s.crosshair) {
        ImU32 c = Col(s.crosshairColor);
        float g = 2.f, l = s.crosshairSize;
        dl->AddLine(ImVec2(cx - g - l, cy), ImVec2(cx - g, cy), c, 1.5f);
        dl->AddLine(ImVec2(cx + g, cy), ImVec2(cx + g + l, cy), c, 1.5f);
        dl->AddLine(ImVec2(cx, cy - g - l), ImVec2(cx, cy - g), c, 1.5f);
        dl->AddLine(ImVec2(cx, cy + g), ImVec2(cx, cy + g + l), c, 1.5f);
    }
}
