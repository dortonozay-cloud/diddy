#pragma once
// KZ aimbot: screen-space target selection + smoothed mouse movement.
void RunAimbot(int screenW, int screenH);
