#pragma once
// KZ ESP rendering (boxes / snaplines / distance / skeleton approximation).
void RenderEsp(int screenW, int screenH);
