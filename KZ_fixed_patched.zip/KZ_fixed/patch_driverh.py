#!/usr/bin/env python3
# patch_driverh.py <suffix> <path_to_driver.h>
# Stamps KZ_DEVICE_NAME with the given suffix.
import sys, re

if len(sys.argv) < 3:
    print("usage: patch_driverh.py <SUFFIX> <driver.h path>")
    sys.exit(1)

suffix = sys.argv[1]
path   = sys.argv[2]

with open(path, 'r') as f:
    content = f.read()

new_line = f'#define KZ_DEVICE_NAME L"\\\\\\\\.\\\\{suffix}"   // PATCHED BY build_all.bat'
content2 = re.sub(
    r'#define KZ_DEVICE_NAME\s+L"[^"]*"[^\n]*',
    new_line,
    content
)

with open(path, 'w') as f:
    f.write(content2)

print(f'[+] driver.h patched: KZ_DEVICE_NAME = \\\\.\\{suffix}')
