@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo ========================================
echo   KZ R6 External - Full Build
echo ========================================
echo.

set "MSBUILD="
if exist "C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\amd64\MSBuild.exe" set "MSBUILD=C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\amd64\MSBuild.exe"
if exist "C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\amd64\MSBuild.exe" set "MSBUILD=C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\amd64\MSBuild.exe"
if exist "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\amd64\MSBuild.exe" set "MSBUILD=C:\Program Files\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\amd64\MSBuild.exe"
if exist "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\amd64\MSBuild.exe" set "MSBUILD=C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\amd64\MSBuild.exe"

if not defined MSBUILD (
    echo [!] MSBuild not found - install VS2022
    pause & exit /b 1
)
echo [*] Found MSBuild

:: Create output dirs
mkdir "mapper\x64\Release" 2>nul

:: Build kdmapper via solution file so include paths resolve correctly
echo [*] Building kdmapper...
"%MSBUILD%" "mapper\kdmapper.sln" /p:Configuration=Release /p:Platform=x64 /t:kdmapper /v:minimal
if errorlevel 1 (
    echo [!] kdmapper build failed
    pause & exit /b 1
)

set "MAPPER_EXE=%~dp0mapper\x64\Release\kdmapper_Release.exe"
if not exist "%MAPPER_EXE%" (
    echo [!] mapper exe not found - checking other locations...
    dir "%~dp0mapper\x64\Release\" 2>nul
    pause & exit /b 1
)
echo [+] kdmapper.exe built

:: Generate device name suffix
set T=%TIME: =0%
set HH=%T:~0,2%
set MM=%T:~3,2%
set SS=%T:~6,2%
set DIGITS=%HH%%MM%%SS%
set SUFFIX=

for /L %%i in (0,1,5) do (
    set "D=!DIGITS:~%%i,1!"
    if "!D!"=="0" set "L=A"
    if "!D!"=="1" set "L=B"
    if "!D!"=="2" set "L=C"
    if "!D!"=="3" set "L=D"
    if "!D!"=="4" set "L=E"
    if "!D!"=="5" set "L=F"
    if "!D!"=="6" set "L=G"
    if "!D!"=="7" set "L=H"
    if "!D!"=="8" set "L=I"
    if "!D!"=="9" set "L=J"
    set "SUFFIX=!SUFFIX!!L!"
)
if "!SUFFIX!"=="" set "SUFFIX=KZRAND"
echo [*] Build suffix: !SUFFIX!

python patch_driverh.py "!SUFFIX!" "src\core\driver.h"
if errorlevel 1 (
    echo [!] Python not found or patch failed
    pause & exit /b 1
)

:: Build kernel driver
echo [*] Building KZKM.sys...
"%MSBUILD%" "driver\KZKM.sln" /p:Configuration=Release /p:Platform=x64 /p:SpectreMitigation=false /p:ALLOW_DATE_TIME=1 "/p:DefineConstants=KZ_NAME_SUFFIX=\"!SUFFIX!\"" /t:Build /v:minimal
if errorlevel 1 (
    echo [!] Driver build failed - is WDK installed?
    pause & exit /b 1
)
echo [+] KZKM.sys built

:: Build usermode overlay
echo [*] Building kz.exe...
"%MSBUILD%" "KZ.sln" /p:Configuration=Release /p:Platform=x64 /t:Build /v:minimal
if errorlevel 1 (
    echo [!] Usermode build failed
    pause & exit /b 1
)
echo [+] kz.exe built

echo.
echo ========================================
echo [+] All done!
echo ========================================
echo [*] Launch R6 Siege, then run RUN_CHEAT.bat as admin
echo.
pause
endlocal
