@echo off
:: ============================================================================
:: generate_names.bat
::
:: Derives the same 6-char suffix the kernel driver uses (__TIME__ at build)
:: and stamps it into src\core\driver.h so usermode opens the right symlink.
::
:: Called automatically by build_all.bat BEFORE building the driver.
:: The suffix is: each digit of HH MM SS mapped A-J (e.g. 01:23:49 -> ABCDEJ)
::
:: Usage: generate_names.bat <HHMMSS>
::   e.g. generate_names.bat 142307
:: Pass %TIME:~0,2%%TIME:~3,2%%TIME:~6,2%  from the calling script.
:: ============================================================================

setlocal

set /a H0=%1:~0,1%
set /a H1=%1:~1,1%
set /a M0=%1:~2,1%
set /a M1=%1:~3,1%
set /a S0=%1:~4,1%
set /a S1=%1:~5,1%

:: Map digit -> letter (0=A, 1=B, ... 9=J)
set ALPHA=ABCDEFGHIJ

:: Extract each character from ALPHA string at position H0..S1
set CH0=!ALPHA:~%H0%,1!
set CH1=!ALPHA:~%H1%,1!
set CM0=!ALPHA:~%M0%,1!
set CM1=!ALPHA:~%M1%,1!
set CS0=!ALPHA:~%S0%,1!
set CS1=!ALPHA:~%S1%,1!

set SUFFIX=%CH0%%CH1%%CM0%%CM1%%CS0%%CS1%

echo [*] Device name suffix this build: %SUFFIX%
echo [*] Usermode will open: \\.\%SUFFIX%

:: Patch src\core\driver.h — replace the KZ_DEVICE_NAME line
set DRvh=%~dp0src\core\driver.h
powershell -Command "(Get-Content '%DRVIH%') -replace '#define KZ_DEVICE_NAME.*', '#define KZ_DEVICE_NAME L\"\\\\\\\\\\\\\\\\.\\\\\\\\\%SUFFIX%\"' | Set-Content '%DRVIH%'"

echo [+] driver.h patched

endlocal
