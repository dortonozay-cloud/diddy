# KZ — Build & Run Guide

## What's in this folder

```
KZ_final/
├── src/                  ← KZ usermode source (overlay, ESP, aimbot, menu, ImGui DX9)
│   ├── core/             ← driver.h (IOCTL client), config, util
│   ├── game/             ← entities (R6 memory reader), offsets
│   ├── features/         ← aimbot, ESP box/skeleton/snaplines, visuals
│   └── ui/               ← ImGui menu (4 tabs), theme
├── vendor/               ← Dear ImGui + stb_image
├── assets/               ← kz_logo.png
├── driver/               ← Full kernel driver (ported from NWR6V2/SebwettKM)
│   ├── Core/             ← ASM ntoskrnl resolver, Crt, Definitions, IoControl, Symbols, Utilities
│   ├── Init/             ← DriverEntry / DriverInitialize, Driverinit helpers
│   └── Modules/
│       ├── EAC/          ← Hooks, Decryption, FunctionBlocker, LogDisable
│       ├── Memory/       ← BaseAddress (PID→base), EProcess, PML4/CR3 scanner
│       ├── MemoryAccess/ ← RWX (physical read/write via page-table walk), Read, Write, + virtual ops
│       ├── MouseMove/    ← Kernel mouse input via MouClass service callback (ASM stub)
│       ├── PatternScan/  ← In-kernel pattern scanner
│       └── Spoofer/      ← HWID spoofing (disk serial, SMBIOS, MAC interception)
├── KZ.vcxproj            ← Usermode VS project
├── KZ.sln                ← Usermode solution
├── driver/KZKM.vcxproj   ← Kernel driver VS project
├── driver/KZKM.sln       ← Kernel driver solution
├── build.bat             ← Build kz.exe
├── build_driver.bat      ← Build KZKM.sys
├── sign_driver.bat       ← Self-sign for test mode
└── load_and_run.bat      ← Load driver + launch kz.exe
```

---

## Requirements

| Tool | Download |
|------|----------|
| Visual Studio 2022 (v143 toolset) | https://visualstudio.microsoft.com/ |
| Windows Driver Kit (WDK 10) | https://learn.microsoft.com/windows-hardware/drivers/download-the-wdk |
| DirectX SDK (June 2010) | https://www.microsoft.com/download/details.aspx?id=6812 |

DirectX SDK default path assumed by the .vcxproj:
`C:\Program Files (x86)\Microsoft DirectX SDK (June 2010)\`

If yours is elsewhere, edit the `<IncludePath>` and `<LibraryPath>` in `KZ.vcxproj`.

---

## Step 1 — Build the kernel driver

```
build_driver.bat
```

Output: `driver\Build\Release\KZKM.sys`

**Prerequisites:**
- WDK installed with VS2022 integration (check via `winver` + Device Manager shows WDK version)

---

## Step 2 — Sign the driver (test mode)

Enable test signing first — one time, requires reboot:

```cmd
bcdedit /set testsigning on
```

Then:

```
sign_driver.bat
```

This creates a self-signed cert, installs it to the machine's trusted stores, and signs `KZKM.sys`.

---

## Step 3 — Build the usermode client

```
build.bat
```

Output: `bin\kz.exe`

---

## Step 4 — Load and run

```
load_and_run.bat   ← must run as Administrator
```

This:
1. Installs `KZKM.sys` as a kernel service (`WinDrvMgr`)
2. Starts the driver (`\\Device\\WinDrvMgr` symbolic link created)
3. Launches `kz.exe`

`kz.exe` will:
- Wait for `RainbowSix.exe` to be running
- Connect to the driver via `CreateFile("\\\\.\\WinDrvMgr")`
- Read the game's base address via IOCTL
- Overlay → **INSERT** toggles menu, **END** unloads

---

## Demo mode (no driver, no game)

```
bin\kz.exe --demo
```

Renders synthetic targets, previews all ESP/menu features without any driver or game.

---

## Offsets

Update `src\game\offsets.h` after game patches. All game-dependent values live there:

- `gameManagerRva` — compressed pointer to the EntityManager in the game image
- `viewTransformRva` — camera block RVA
- `teamId`, `health0-3` — per-actor chain offsets
- `plainPos`, `encRoots`, `encNodeOff` — position read paths (plain float or MBA-decrypted)

---

## Driver IOCTL contract

`src\core\driver.h` defines the wire protocol. IOCTLs match NWR6V2's codes exactly:

| Code | Function | Struct |
|------|----------|--------|
| `0x2A2` | Get module base by PID | `KzBaseRequest` |
| `0x2A4` | Read process memory (phys) | `KzReadRequest` |
| `0x2A5` | Write process memory (phys) | `KzWriteRequest` |
| `0x3A1` | Kernel mouse move | `KzMouseRequest` |

The driver uses a page-table walk (PML4 → CR3 resolution) for all reads/writes — no `MmCopyVirtualMemory`, no attach/detach.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| `sc start` fails with error 577 | Test signing not enabled — `bcdedit /set testsigning on` + reboot |
| `[KZ] driver not available` in kz.exe | Driver not loaded — check `sc query WinDrvMgr` |
| ESP works but aimbot doesn't move mouse | Kernel mouse init failed — check `mousemove::OpenMouse` (MouClass/MouHID must be running) |
| Wrong entity positions after patch | Update `offsets.h` — dump game memory to find new RVAs |
| `[!] game process not found` | Run kz.exe after game is fully loaded |
