#include "../Includes.h"
#include "../Core/DeviceNames.h"

#define ExAllocatePoolnew(a, b) NT.ExAllocatePoolWithTag(NonPagedPool, b, 'KZDr')

uint64_t  g_original_function = 0;
BYTE      g_original_bytes[64] = { 0 };
PDEVICE_OBJECT g_DeviceObject = nullptr;
UNICODE_STRING g_SymbolicLink = { 0 };

extern "C" NTSTATUS IoCreateDriver(PUNICODE_STRING DriverName,
    OPTIONAL PDRIVER_INITIALIZE InitializationFunction);

#include "../Modules/Spoofer/Spoofer.h"

VOID CleanupDriver()
{
    Spoofer::Cleanup();
    EACHooks::UninstallHooks();

    if (g_SymbolicLink.Buffer != nullptr) {
        IoDeleteSymbolicLink(&g_SymbolicLink);
        RtlFreeUnicodeString(&g_SymbolicLink);
        g_SymbolicLink.Buffer = nullptr;
    }
    if (g_DeviceObject != nullptr) {
        IoDeleteDevice(g_DeviceObject);
        g_DeviceObject = nullptr;
    }
}

VOID DummyUnload(PDRIVER_OBJECT DriverObject)
{
    UNREFERENCED_PARAMETER(DriverObject);
    CleanupDriver();
}

NTSTATUS DeviceDispatch(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    return IoControl::Dispatch(DeviceObject, Irp);
}

NTSTATUS DriverInitialize(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
    UNREFERENCED_PARAMETER(RegistryPath);

    DriverObject->DriverUnload = DummyUnload;
    for (int i = 0; i <= IRP_MJ_MAXIMUM_FUNCTION; i++)
        DriverObject->MajorFunction[i] = DeviceDispatch;

    // ---- randomised device name (derived from __TIME__ at build) ----
    WCHAR devBuf[64], symBuf[64], symCopyBuf[64];
    KzNames::BuildDevicePath(devBuf);
    KzNames::BuildSymlinkPath(symBuf);

    UNICODE_STRING deviceName;
    deviceName.Buffer        = devBuf;
    deviceName.Length        = (USHORT)(wcslen(devBuf) * sizeof(WCHAR));
    deviceName.MaximumLength = (USHORT)sizeof(devBuf);

    NTSTATUS status = IoCreateDevice(
        DriverObject, 0, &deviceName,
        FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN,
        FALSE, &g_DeviceObject
    );
    if (!NT_SUCCESS(status))
        return status;

    g_DeviceObject->Flags |= DO_BUFFERED_IO;
    g_DeviceObject->Flags &= ~DO_DEVICE_INITIALIZING;

    UNICODE_STRING symbolicLink;
    symbolicLink.Buffer        = symBuf;
    symbolicLink.Length        = (USHORT)(wcslen(symBuf) * sizeof(WCHAR));
    symbolicLink.MaximumLength = (USHORT)sizeof(symBuf);

    IoDeleteSymbolicLink(&symbolicLink);
    status = IoCreateSymbolicLink(&symbolicLink, &deviceName);
    if (!NT_SUCCESS(status)) {
        IoDeleteDevice(g_DeviceObject);
        return status;
    }

    // Keep a persistent copy of the symlink path for cleanup
    SIZE_T symLen   = wcslen(symBuf) + 1;
    WCHAR* symCopy  = (WCHAR*)ExAllocatePoolnew(NonPagedPool, symLen * sizeof(WCHAR));
    if (symCopy) {
        RtlCopyMemory(symCopy, symBuf, symLen * sizeof(WCHAR));
        RtlInitUnicodeString(&g_SymbolicLink, symCopy);
    }

    Spoofer::Initialize();
    EACHooks::setup();

    return STATUS_SUCCESS;
}

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
    if (!Resolver.SetupASM())
        return STATUS_UNSUCCESSFUL;

    Utility::InitRandom();
    mousemove::InitializeMouseControl();

    if (DriverObject != nullptr)
        return DriverInitialize(DriverObject, RegistryPath);

    // Manual mapping fallback — driver object name also randomised
    WCHAR drvBuf[64];
    KzNames::BuildDriverPath(drvBuf);

    UNICODE_STRING driverNameU;
    driverNameU.Buffer        = drvBuf;
    driverNameU.Length        = (USHORT)(wcslen(drvBuf) * sizeof(WCHAR));
    driverNameU.MaximumLength = (USHORT)sizeof(drvBuf);

    NTSTATUS status = IoCreateDriver(&driverNameU, DriverInitialize);
    if (!NT_SUCCESS(status))
        return STATUS_INSUFFICIENT_RESOURCES;

    return STATUS_SUCCESS;
}
