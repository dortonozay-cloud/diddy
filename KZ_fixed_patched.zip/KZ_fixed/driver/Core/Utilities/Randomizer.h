#pragma once
#include "../../Includes.h"

namespace Randomizer
{
    inline char RandomChar()
    {
        const char charset[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return charset[Utility::InitRandom() % (sizeof(charset) - 1)];
    }

    inline char RandomHexChar(bool uppercase = true)
    {
        const char charset_up[] = "0123456789ABCDEF";
        const char charset_lo[] = "0123456789abcdef";
        return uppercase ? charset_up[Utility::InitRandom() % 16] : charset_lo[Utility::InitRandom() % 16];
    }

    // mutationRate as integer percentage (0-100) — no floats in kernel
    inline void MutateSerial(char* serial, int mutationPct = 30)
    {
        if (!serial) return;
        SIZE_T len = 0;
        while (serial[len]) len++;
        for (SIZE_T i = 0; i < len; i++)
        {
            if (serial[i] == '-' || serial[i] == '_' || serial[i] == ' ' || serial[i] == '.')
                continue;
            if ((int)(Utility::InitRandom() % 100) < mutationPct)
            {
                if (serial[i] >= '0' && serial[i] <= '9')
                    serial[i] = '0' + (Utility::InitRandom() % 10);
                else if (serial[i] >= 'A' && serial[i] <= 'Z')
                    serial[i] = 'A' + (Utility::InitRandom() % 26);
                else if (serial[i] >= 'a' && serial[i] <= 'z')
                    serial[i] = 'a' + (Utility::InitRandom() % 26);
            }
        }
    }

    inline void GenerateRandomString(char* buffer, SIZE_T length)
    {
        for (SIZE_T i = 0; i < length; i++)
            buffer[i] = RandomChar();
        buffer[length] = '\0';
    }

    inline void GenerateRandomMAC(unsigned char* mac)
    {
        for (int i = 0; i < 6; i++)
            mac[i] = (unsigned char)(Utility::InitRandom() & 0xFF);
        mac[0] &= 0xFE;
        mac[0] |= 0x02;
    }
}
