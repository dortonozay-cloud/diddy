#pragma once
// ============================================================================
// DeviceNames.h — build-time stamped device/symlink/driver name strings.
//
// The suffix is NOT derived from __TIME__ (WDK blocks it via /d1nodatetime).
// Instead build_all.bat stamps KZ_NAME_SUFFIX directly before building,
// producing a unique 6-char alpha string per build.
//
// Do not edit KZ_NAME_SUFFIX manually — run build_all.bat.
// ============================================================================
#include <ntifs.h>

// Stamped by build_all.bat — one unique value per build e.g. "BGDFFI"
#ifndef KZ_NAME_SUFFIX
#define KZ_NAME_SUFFIX "AAAAAA"
#endif

// Wide version for Unicode strings
#define KZ_NAME_SUFFIX_W L"" KZ_NAME_SUFFIX

namespace KzNames {

    inline void BuildDevicePath(WCHAR* buf) {
        const WCHAR pre[] = L"\\Device\\";
        const WCHAR suf[] = KZ_NAME_SUFFIX_W;
        WCHAR* p = buf;
        for (const WCHAR* s = pre; *s; ++s) *p++ = *s;
        for (const WCHAR* s = suf; *s; ++s) *p++ = *s;
        *p = L'\0';
    }

    inline void BuildSymlinkPath(WCHAR* buf) {
        const WCHAR pre[] = L"\\??\\";
        const WCHAR suf[] = KZ_NAME_SUFFIX_W;
        WCHAR* p = buf;
        for (const WCHAR* s = pre; *s; ++s) *p++ = *s;
        for (const WCHAR* s = suf; *s; ++s) *p++ = *s;
        *p = L'\0';
    }

    inline void BuildDriverPath(WCHAR* buf) {
        const WCHAR pre[] = L"\\Driver\\";
        const WCHAR suf[] = KZ_NAME_SUFFIX_W;
        WCHAR* p = buf;
        for (const WCHAR* s = pre; *s; ++s) *p++ = *s;
        for (const WCHAR* s = suf; *s; ++s) *p++ = *s;
        *p = L'\0';
    }

} // namespace KzNames
