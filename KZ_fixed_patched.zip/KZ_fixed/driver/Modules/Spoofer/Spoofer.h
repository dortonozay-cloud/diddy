#pragma once
#include "../../Includes.h"
#include <ntddstor.h>
#include <mountdev.h>
#include <ntdddisk.h>
#include <ntddscsi.h>
#include <ntddvol.h>

namespace Spoofer
{
    // Per-session randomised identity (set once in Initialize, reused per IRP)
    extern char  g_DiskSerial[128];
    extern char  g_SMBIOSSerial[64];
    extern char  g_UUID[64];
    extern unsigned char g_MAC[6];

    // Public API
    NTSTATUS Initialize();
    void     Cleanup();

    // IRP dispatch hooks installed on disk and NDIS driver objects
    NTSTATUS HookedDiskDispatch(PDEVICE_OBJECT device, PIRP irp);
    NTSTATUS HookedNdisDispatch(PDEVICE_OBJECT device, PIRP irp);

    // IRP completion routines (set via IoSetCompletionRoutine)
    NTSTATUS DiskControlCompletion(PDEVICE_OBJECT device, PIRP irp, PVOID ctx);
    NTSTATUS NdisControlCompletion(PDEVICE_OBJECT device, PIRP irp, PVOID ctx);

    // Original dispatch pointers saved before hook
    extern PDRIVER_DISPATCH g_OrigDiskDispatch;
    extern PDRIVER_DISPATCH g_OrigNdisDispatch;

    inline bool g_Initialized = false;

    // Internal helpers
    void PatchStorageSerial(PVOID buf, ULONG bufLen);
    void PatchSmartData(PVOID buf, ULONG bufLen);
    void PatchAtaIdentify(PVOID buf, ULONG bufLen);
    void PatchScsiVpd(PVOID buf, ULONG bufLen, UCHAR page);
}
