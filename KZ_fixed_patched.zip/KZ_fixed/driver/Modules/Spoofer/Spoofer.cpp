// ============================================================================
// KZ Spoofer — full IRP completion hook implementation.
//
// Hooks the disk (disk.sys / classpnp.sys) and NDIS driver dispatch tables.
// Intercepts IRP_MJ_DEVICE_CONTROL completion and patches serial/identity
// data in-place before the result reaches the caller (EAC, game, OS).
//
// Covers:
//   Disk   IOCTL_STORAGE_QUERY_PROPERTY (StorageDeviceProperty serial)
//          SMART_RCV_DRIVE_DATA          (ATA SMART serial + power-on hours)
//          IOCTL_ATA_PASS_THROUGH(_DIRECT) (ATA IDENTIFY word 10-19)
//          IOCTL_SCSI_PASS_THROUGH(_DIRECT) (VPD page 0x80 unit serial)
//          IOCTL_STORAGE_GET_DEVICE_NUMBER (serial patched to 0 in descriptor)
//   NIC    OID_802_3_PERMANENT_ADDRESS / OID_802_3_CURRENT_ADDRESS (MAC)
// ============================================================================

#include "Spoofer.h"
#include "../../Core/Utilities/Randomizer.h"
#include <ntddstor.h>
#include <mountdev.h>
#include <ntdddisk.h>
#include <ntddscsi.h>
#include <ntddvol.h>
#include <ndisguid.h>

// OID values not always in WDK headers at kernel level
#ifndef OID_802_3_PERMANENT_ADDRESS
#define OID_802_3_PERMANENT_ADDRESS 0x01010101
#endif
#ifndef OID_802_3_CURRENT_ADDRESS
#define OID_802_3_CURRENT_ADDRESS   0x01010102
#endif

// ATA IDENTIFY response structure (relevant words only)
#pragma pack(push, 1)
struct AtaIdentifyData {
    USHORT  words00_09[10];  // [0-9]
    USHORT  SerialNumber[10]; // words 10-19, 20 bytes of serial (right-padded spaces)
    USHORT  words20_22[3];
    USHORT  FirmwareRevision[4]; // words 23-26
    USHORT  ModelNumber[20];     // words 27-46
    // rest omitted — only serial matters
};
#pragma pack(pop)

// SCSI CDB for INQUIRY
#pragma pack(push, 1)
struct ScsiInquiryCdb {
    UCHAR OperationCode;  // 0x12
    UCHAR EVPD;           // bit0 = 1 for VPD
    UCHAR PageCode;
    UCHAR AllocationLengthMsb;
    UCHAR AllocationLengthLsb;
    UCHAR Control;
};
// VPD page 0x80 (Unit Serial Number)
struct VpdUnitSerialPage {
    UCHAR DeviceType;
    UCHAR PageCode;   // 0x80
    UCHAR Reserved;
    UCHAR PageLength;
    UCHAR SerialNumber[1]; // variable length, PageLength bytes
};
#pragma pack(pop)

namespace Spoofer {

// Per-session identity — mutated in Initialize()
char         g_DiskSerial[128]   = "ACE4_2E00_2A1F_E803_2EE4_AC00_0000_0001";
char         g_SMBIOSSerial[64]  = "PF3NLC44";
char         g_UUID[64]          = "6B03B789-9528-11EC-80F1-88A4C2C5C6C1";
unsigned char g_MAC[6]           = { 0xE0, 0x0A, 0xF6, 0x74, 0x2D, 0x43 };

PDRIVER_DISPATCH g_OrigDiskDispatch = nullptr;
PDRIVER_DISPATCH g_OrigNdisDispatch = nullptr;

// ---- helper: safe strlen for kernel buffers --------------------------------
static SIZE_T SafeStrlen(const char* s, SIZE_T max) {
    SIZE_T n = 0;
    while (n < max && s[n]) n++;
    return n;
}

// ---- helper: copy serial into fixed-width field, space-padded ---------------
static void FillSerial(PVOID dst, SIZE_T fieldLen, const char* src) {
    char* d = (char*)dst;
    SIZE_T slen = SafeStrlen(src, fieldLen);
    SIZE_T i = 0;
    for (; i < slen && i < fieldLen; i++) d[i] = src[i];
    for (; i < fieldLen; i++) d[i] = ' ';
}

// ---- STORAGE_DEVICE_DESCRIPTOR serial patch --------------------------------
void PatchStorageSerial(PVOID buf, ULONG bufLen) {
    if (bufLen < sizeof(STORAGE_DEVICE_DESCRIPTOR)) return;
    PSTORAGE_DEVICE_DESCRIPTOR desc = (PSTORAGE_DEVICE_DESCRIPTOR)buf;
    if (desc->SerialNumberOffset == 0 ||
        desc->SerialNumberOffset >= bufLen) return;

    char* serial = (char*)buf + desc->SerialNumberOffset;
    SIZE_T remaining = bufLen - desc->SerialNumberOffset;
    SIZE_T slen = SafeStrlen(g_DiskSerial, remaining);
    RtlCopyMemory(serial, g_DiskSerial, slen);
    if (slen < remaining) serial[slen] = '\0';
}

// ---- ATA SMART (SENDCMDINPARAMS / SENDCMDOUTPARAMS) serial patch -----------
// SENDCMDOUTPARAMS.bBuffer starts with IDSECTOR (ATA IDENTIFY DATA).
// Words 10-19 (bytes 20-39 of IDSECTOR) = 20-char serial, space-padded.
#pragma pack(push, 1)
struct IdSectorSerial {
    UCHAR pad[20];         // words 0-9
    UCHAR SerialNo[20];    // words 10-19
};
#pragma pack(pop)

void PatchSmartData(PVOID buf, ULONG bufLen) {
    // bBuffer in SENDCMDOUTPARAMS starts at offset 4 (dwBufferSize + bDriverError + bIDEError + bReserved[2])
    // For IDENTIFY_BUFFER_SIZE (512 bytes), the entire buffer is IDSECTOR.
    // Just look for the serial at offset 20.
    if (bufLen < sizeof(IdSectorSerial)) return;
    IdSectorSerial* id = (IdSectorSerial*)buf;
    // ATA serials are big-endian pairs — swap bytes per word
    char swapped[20];
    SIZE_T slen = SafeStrlen(g_DiskSerial, 20);
    SIZE_T i = 0;
    for (; i < slen && i < 20; i++) swapped[i] = g_DiskSerial[i];
    for (; i < 20; i++) swapped[i] = ' ';
    // Byte-swap per word (ATA convention)
    for (i = 0; i < 20; i += 2) {
        id->SerialNo[i]   = swapped[i + 1];
        id->SerialNo[i+1] = swapped[i];
    }
}

// ---- ATA_PASS_THROUGH: response buffer = ATA IDENTIFY data -----------------
void PatchAtaIdentify(PVOID buf, ULONG bufLen) {
    // buf starts with ATA_PASS_THROUGH_EX, then data buffer immediately after
    // The caller allocated sizeof(ATA_PASS_THROUGH_EX) + 512 bytes.
    // We only care about the data portion; DataBufferOffset tells us where it is.
    if (bufLen < sizeof(ATA_PASS_THROUGH_EX) + sizeof(IdSectorSerial)) return;
    PATA_PASS_THROUGH_EX apt = (PATA_PASS_THROUGH_EX)buf;
    if (apt->DataBufferOffset == 0) return;
    if (apt->DataBufferOffset + sizeof(IdSectorSerial) > bufLen) return;
    PVOID data = (PUCHAR)buf + apt->DataBufferOffset;
    PatchSmartData(data, (ULONG)(bufLen - apt->DataBufferOffset));
}

// ---- SCSI VPD page 0x80 (Unit Serial Number) patch ------------------------
void PatchScsiVpd(PVOID buf, ULONG bufLen, UCHAR page) {
    if (page != 0x80) return;   // only handle unit serial page
    if (bufLen < sizeof(VpdUnitSerialPage)) return;
    VpdUnitSerialPage* vpd = (VpdUnitSerialPage*)buf;
    SIZE_T serialLen = (SIZE_T)vpd->PageLength;
    if (serialLen == 0 || sizeof(VpdUnitSerialPage) - 1 + serialLen > bufLen)
        return;
    FillSerial(vpd->SerialNumber, serialLen, g_DiskSerial);
}

// ---- SCSI passthrough dispatch ---------------------------------------------
static void HandleScsiPassthrough(PVOID buf, ULONG bufLen, bool isDirect) {
    // Both IOCTL_SCSI_PASS_THROUGH and _DIRECT use SCSI_PASS_THROUGH(_DIRECT)
    // as the input/output header; data follows at DataBufferOffset.
    PSCSI_PASS_THROUGH spt = (PSCSI_PASS_THROUGH)buf;
    if (bufLen < sizeof(SCSI_PASS_THROUGH)) return;
    if (spt->DataBufferOffset == 0) return;
    if (spt->DataTransferLength < sizeof(VpdUnitSerialPage)) return;
    if (spt->DataBufferOffset + spt->DataTransferLength > bufLen) return;

    // CDB byte 0 = INQUIRY (0x12), byte 1 bit0 = EVPD, byte 2 = page code
    UCHAR opcode = spt->Cdb[0];
    UCHAR evpd   = spt->Cdb[1] & 0x01;
    UCHAR page   = spt->Cdb[2];

    if (opcode == 0x12 && evpd) {
        PVOID data = (PUCHAR)buf + spt->DataBufferOffset;
        PatchScsiVpd(data, spt->DataTransferLength, page);
    }
}

// ============================================================================
// IRP completion routine — disk
// ============================================================================
NTSTATUS DiskControlCompletion(PDEVICE_OBJECT DeviceObject, PIRP Irp, PVOID Context)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    UNREFERENCED_PARAMETER(Context);

    if (Irp->PendingReturned)
        IoMarkIrpPending(Irp);

    if (!NT_SUCCESS(Irp->IoStatus.Status))
        return Irp->IoStatus.Status;

    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    if (stack->MajorFunction != IRP_MJ_DEVICE_CONTROL)
        return Irp->IoStatus.Status;

    ULONG ioctl   = stack->Parameters.DeviceIoControl.IoControlCode;
    PVOID sysBuf  = Irp->AssociatedIrp.SystemBuffer;
    ULONG outLen  = stack->Parameters.DeviceIoControl.OutputBufferLength;

    __try {
        if (ioctl == IOCTL_STORAGE_QUERY_PROPERTY) {
            PSTORAGE_PROPERTY_QUERY q = (PSTORAGE_PROPERTY_QUERY)sysBuf;
            if (q->PropertyId == StorageDeviceProperty)
                PatchStorageSerial(sysBuf, outLen);
        }
        else if (ioctl == SMART_RCV_DRIVE_DATA) {
            // Output = SENDCMDOUTPARAMS; bBuffer at offset 16 for a standard response
            if (outLen >= 16)
                PatchSmartData((PUCHAR)sysBuf + 16, outLen - 16);
        }
        else if (ioctl == IOCTL_ATA_PASS_THROUGH ||
                 ioctl == IOCTL_ATA_PASS_THROUGH_DIRECT) {
            PatchAtaIdentify(sysBuf, outLen);
        }
        else if (ioctl == IOCTL_SCSI_PASS_THROUGH) {
            HandleScsiPassthrough(sysBuf, outLen, false);
        }
        else if (ioctl == IOCTL_SCSI_PASS_THROUGH_DIRECT) {
            HandleScsiPassthrough(sysBuf, outLen, true);
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        // swallow — never crash on completion
    }

    return Irp->IoStatus.Status;
}

// ============================================================================
// IRP completion routine — NIC (NDIS / ndiswanip)
// ============================================================================
NTSTATUS NdisControlCompletion(PDEVICE_OBJECT DeviceObject, PIRP Irp, PVOID Context)
{
    UNREFERENCED_PARAMETER(DeviceObject);
    UNREFERENCED_PARAMETER(Context);

    if (Irp->PendingReturned)
        IoMarkIrpPending(Irp);

    if (!NT_SUCCESS(Irp->IoStatus.Status))
        return Irp->IoStatus.Status;

    // NDIS OID requests arrive via METHOD_NEITHER IRPs.
    // The input buffer is NDIS_OID_REQUEST-shaped; for direct IOCTL the OID
    // is at a known offset inside the system buffer.  Many miniport IOCTL
    // wrappers put the OID at offset 0 as a ULONG.
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    if (stack->MajorFunction != IRP_MJ_DEVICE_CONTROL)
        return Irp->IoStatus.Status;

    PVOID buf    = Irp->AssociatedIrp.SystemBuffer;
    ULONG outLen = stack->Parameters.DeviceIoControl.OutputBufferLength;
    if (!buf || outLen < 6) return Irp->IoStatus.Status;

    __try {
        // Try to read the OID from the start of the buffer
        ULONG oid = *(ULONG*)buf;
        if (oid == OID_802_3_PERMANENT_ADDRESS ||
            oid == OID_802_3_CURRENT_ADDRESS) {
            // MAC address follows the OID ULONG in many wrapper layouts
            if (outLen >= sizeof(ULONG) + 6)
                RtlCopyMemory((PUCHAR)buf + sizeof(ULONG), g_MAC, 6);
            // Also try at offset 0 in case layout is MAC-only
            else if (outLen >= 6)
                RtlCopyMemory(buf, g_MAC, 6);
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {}

    return Irp->IoStatus.Status;
}

// ============================================================================
// Hooked dispatch — disk
// Sets our completion routine and calls the original dispatch.
// ============================================================================
NTSTATUS HookedDiskDispatch(PDEVICE_OBJECT device, PIRP irp)
{
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(irp);

    if (stack->MajorFunction == IRP_MJ_DEVICE_CONTROL) {
        IoCopyCurrentIrpStackLocationToNext(irp);
        IoSetCompletionRoutine(irp, DiskControlCompletion,
                               nullptr, TRUE, TRUE, TRUE);
    }

    if (g_OrigDiskDispatch)
        return g_OrigDiskDispatch(device, irp);

    irp->IoStatus.Status      = STATUS_NOT_SUPPORTED;
    irp->IoStatus.Information = 0;
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    return STATUS_NOT_SUPPORTED;
}

// ============================================================================
// Hooked dispatch — NDIS
// ============================================================================
NTSTATUS HookedNdisDispatch(PDEVICE_OBJECT device, PIRP irp)
{
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(irp);

    if (stack->MajorFunction == IRP_MJ_DEVICE_CONTROL) {
        IoCopyCurrentIrpStackLocationToNext(irp);
        IoSetCompletionRoutine(irp, NdisControlCompletion,
                               nullptr, TRUE, TRUE, TRUE);
    }

    if (g_OrigNdisDispatch)
        return g_OrigNdisDispatch(device, irp);

    irp->IoStatus.Status      = STATUS_NOT_SUPPORTED;
    irp->IoStatus.Information = 0;
    IoCompleteRequest(irp, IO_NO_INCREMENT);
    return STATUS_NOT_SUPPORTED;
}

// ============================================================================
// Install hooks
// ============================================================================
static NTSTATUS HookDriver(const WCHAR* driverName, PDRIVER_DISPATCH* origOut,
                            PDRIVER_DISPATCH hookFn)
{
    UNICODE_STRING us;
    NT.RtlInitUnicodeString(&us, driverName);

    PDRIVER_OBJECT drvObj = nullptr;
    NTSTATUS status = (NT.ObReferenceObjectByName)(
        &us, OBJ_CASE_INSENSITIVE, nullptr, 0,
        *(POBJECT_TYPE*)(IoDriverObjectType),
        KernelMode, nullptr, (PVOID*)&drvObj
    );
    if (!NT_SUCCESS(status) || !drvObj)
        return STATUS_NOT_FOUND;

    // Save original and patch IRP_MJ_DEVICE_CONTROL
    *origOut = drvObj->MajorFunction[IRP_MJ_DEVICE_CONTROL];
    // WriteSafe handles MDL remapping so we don't need CR0 tricks
    PDRIVER_DISPATCH hook = hookFn;
    Utility::WriteSafe(
        &drvObj->MajorFunction[IRP_MJ_DEVICE_CONTROL],
        &hook, sizeof(hook)
    );

    (NT.ObfDereferenceObject)(drvObj);
    return STATUS_SUCCESS;
}

// ============================================================================
// Initialize / Cleanup
// ============================================================================
NTSTATUS Initialize()
{
    if (g_Initialized) return STATUS_SUCCESS;

    // Randomise identity for this session
    Randomizer::MutateSerial(g_DiskSerial,  40);
    Randomizer::MutateSerial(g_SMBIOSSerial, 50);
    Randomizer::MutateSerial(g_UUID,         30);
    Randomizer::GenerateRandomMAC(g_MAC);

    // Hook disk class driver
    HookDriver(E(L"\\Driver\\Disk"),     &g_OrigDiskDispatch, HookedDiskDispatch);
    // Also try classpnp (used by some configurations instead of disk.sys)
    if (!g_OrigDiskDispatch)
        HookDriver(E(L"\\Driver\\ClassPnP"), &g_OrigDiskDispatch, HookedDiskDispatch);

    // Hook NDIS (NIC MAC spoofing)
    HookDriver(E(L"\\Driver\\NDIS"),     &g_OrigNdisDispatch, HookedNdisDispatch);

    g_Initialized = true;
    return STATUS_SUCCESS;
}

void Cleanup()
{
    if (!g_Initialized) return;

    // Restore original dispatch pointers
    auto RestoreDriver = [](const WCHAR* name, PDRIVER_DISPATCH orig) {
        if (!orig) return;
        UNICODE_STRING us;
        NT.RtlInitUnicodeString(&us, name);
        PDRIVER_OBJECT drvObj = nullptr;
        NTSTATUS s = (NT.ObReferenceObjectByName)(
            &us, OBJ_CASE_INSENSITIVE, nullptr, 0,
            *(POBJECT_TYPE*)(IoDriverObjectType),
            KernelMode, nullptr, (PVOID*)&drvObj
        );
        if (NT_SUCCESS(s) && drvObj) {
            Utility::WriteSafe(&drvObj->MajorFunction[IRP_MJ_DEVICE_CONTROL],
                               &orig, sizeof(orig));
            (NT.ObfDereferenceObject)(drvObj);
        }
    };

    RestoreDriver(E(L"\\Driver\\Disk"),     g_OrigDiskDispatch);
    RestoreDriver(E(L"\\Driver\\ClassPnP"), g_OrigDiskDispatch);
    RestoreDriver(E(L"\\Driver\\NDIS"),     g_OrigNdisDispatch);

    g_OrigDiskDispatch = nullptr;
    g_OrigNdisDispatch = nullptr;
    g_Initialized      = false;
}

} // namespace Spoofer
